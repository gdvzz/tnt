# encoding: utf-8
import argparse
import time

import cv2 as cv
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# 导入人脸网格的连接信息，用于手动绘图
from mediapipe.python.solutions.face_mesh_connections import (
    FACEMESH_CONTOURS,
    FACEMESH_TESSELATION,
)

# 默认优先使用的设备（2K USB Camera 的采集节点）
DEFAULT_DEVICES = ["/dev/video2", "/dev/video4", "/dev/video0"]


def resolve_device(user_device=None):
    """
    解析要使用的摄像头设备路径。
    优先级：
        1. 命令行显式传入的设备
        2. 默认列表里第一个可用的设备（优先 2K USB Camera）
        3. 回退到索引 0（OpenCV 默认摄像头）
    :param user_device: 用户通过命令行传入的设备路径，可为 None。
    :return: OpenCV VideoCapture 可接受的设备标识（字符串路径或整数）。
    """
    import os

    if user_device:
        # 允许传 /dev/videoX，也允许直接传数字（如 0、2）
        if user_device.startswith("/dev/"):
            if not os.path.exists(user_device):
                raise FileNotFoundError(f"设备不存在: {user_device}")
            return user_device
        return int(user_device)

    for dev in DEFAULT_DEVICES:
        if os.path.exists(dev):
            print(f"[信息] 自动选择摄像头设备: {dev}")
            return dev

    print("[警告] 未找到默认设备，回退到索引 0")
    return 0


class FaceMeshDetector:
    def __init__(self, model_path="face_landmarker.task", maxFaces=2):
        """
        使用 Task API 和本地模型文件来初始化人脸网格检测器。
        :param model_path: .task 模型文件的路径。
        :param maxFaces: 要检测的最大人脸数。
        """
        base_options = python.BaseOptions(model_asset_path=model_path)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options, num_faces=maxFaces
        )
        # 创建人脸地标检测器
        self.landmarker = vision.FaceLandmarker.create_from_options(options)

    def find_face_mesh(self, frame, draw=True):
        """
        在一帧图像中寻找人脸网格，并手动绘制它们。
        :param frame: 输入的视频帧 (BGR 格式)。
        :param draw: 是否在图像上绘制网格。
        :return: 处理后的图像, 只有骨架的黑色图像, 以及关键点列表。
        """
        h, w, _ = frame.shape
        img_RGB = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=img_RGB)
        detection_result = self.landmarker.detect(mp_image)

        processed_frame = frame.copy()
        skeleton_img = np.zeros(frame.shape, np.uint8)

        if detection_result.face_landmarks and draw:
            # 遍历检测到的每一张脸
            for face_landmarks in detection_result.face_landmarks:

                # 1. 绘制脸部轮廓线 (与原脚本行为一致)
                # 如果想绘制完整的网格，可以使用 FACEMESH_TESSELATION
                for connection in FACEMESH_CONTOURS:
                    start_idx = connection[0]
                    end_idx = connection[1]

                    if start_idx < len(face_landmarks) and end_idx < len(
                        face_landmarks
                    ):
                        start_landmark = face_landmarks[start_idx]
                        end_landmark = face_landmarks[end_idx]

                        start_point = (
                            int(start_landmark.x * w),
                            int(start_landmark.y * h),
                        )
                        end_point = (int(end_landmark.x * w), int(end_landmark.y * h))

                        # 在两个图像上都画线
                        cv.line(processed_frame, start_point, end_point, (0, 255, 0), 1)
                        cv.line(skeleton_img, start_point, end_point, (0, 255, 0), 1)

                # 2. 绘制轮廓上的关键点
                for landmark in face_landmarks:
                    cx, cy = int(landmark.x * w), int(landmark.y * h)
                    cv.circle(processed_frame, (cx, cy), 1, (0, 0, 255), -1)
                    cv.circle(skeleton_img, (cx, cy), 1, (0, 0, 255), -1)

                # --- 手动绘图结束 ---

        return processed_frame, skeleton_img, detection_result.face_landmarks

    def frame_combine(self, frame, src):
        """水平拼接两个图像。"""
        if len(frame.shape) == 3:
            frameH, frameW = frame.shape[:2]
            srcH, srcW = src.shape[:2]
            dst = np.zeros((max(frameH, srcH), frameW + srcW, 3), np.uint8)
            dst[:, :frameW] = frame[:, :]
            dst[:, frameW:] = src[:, :]
        else:
            src = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
            frameH, frameW = frame.shape[:2]
            imgH, imgW = src.shape[:2]
            dst = np.zeros((frameH, frameW + imgW), np.uint8)
            dst[:, :frameW] = frame[:, :]
            dst[:, frameW:] = src[:, :]
        return dst


def parse_args():
    parser = argparse.ArgumentParser(
        description="MediaPipe 人脸网格检测（默认使用 2K USB Camera）"
    )
    parser.add_argument(
        "device",
        nargs="?",
        default=None,
        help="摄像头设备路径或索引，例如 /dev/video4 或 2。不传则自动选择 2K USB Camera。",
    )
    parser.add_argument(
        "--width", type=int, default=640, help="采集分辨率宽度，默认 640"
    )
    parser.add_argument(
        "--height", type=int, default=480, help="采集分辨率高度，默认 480"
    )
    parser.add_argument(
        "--model",
        default="face_landmarker.task",
        help="人脸地标模型文件路径，默认 face_landmarker.task",
    )
    parser.add_argument(
        "--max-faces", type=int, default=2, help="最大检测人脸数，默认 2"
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    device = resolve_device(args.device)
    print(f"[信息] 使用设备: {device}")

    # Jetson 上建议显式指定 V4L2 后端，避免 GStreamer 管线协商问题
    capture = cv.VideoCapture(device, cv.CAP_V4L2)
    if not capture.isOpened():
        # 回退到默认后端
        capture = cv.VideoCapture(device)

    if not capture.isOpened():
        raise RuntimeError(f"无法打开摄像头设备: {device}")

    capture.set(cv.CAP_PROP_FRAME_WIDTH, args.width)
    capture.set(cv.CAP_PROP_FRAME_HEIGHT, args.height)
    print("摄像头FPS: ", capture.get(cv.CAP_PROP_FPS))

    pTime, cTime = 0, 0
    face_mesh_detector = FaceMeshDetector(
        model_path=args.model, maxFaces=args.max_faces
    )

    while capture.isOpened():
        ret, frame = capture.read()
        if not ret:
            print("读取视频帧失败，退出。")
            break

        frame = cv.flip(frame, 1)

        processed_frame, skeleton_img, landmarks = face_mesh_detector.find_face_mesh(
            frame, draw=True
        )

        # 如果需要使用关键点数据，可以在这里处理 `landmarks`
        if landmarks:
            # landmarks 是一个列表，包含检测到的每张脸的关键点
            # first_face_landmarks = landmarks[0]
            # 例如，打印第一张脸的鼻尖关键点(索引为1)的坐标
            # nose_tip = first_face_landmarks[1]
            # print(f"Nose Tip: x={nose_tip.x}, y={nose_tip.y}")
            pass

        cTime = time.time()
        fps = 1 / (cTime - pTime) if (cTime - pTime) > 0 else 0
        pTime = cTime
        text = "FPS : " + str(int(fps))
        cv.putText(
            processed_frame,
            text,
            (20, 30),
            cv.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 0, 255),
            2,
        )

        dst = face_mesh_detector.frame_combine(processed_frame, skeleton_img)
        cv.imshow("Face Mesh Detection", dst)

        if cv.waitKey(1) & 0xFF == ord("q"):
            break

    capture.release()
    cv.destroyAllWindows()
