# encoding: utf-8
import argparse
import math
import os
import time

import cv2 as cv
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# 导入手部连接信息，用于手动绘图
from mediapipe.python.solutions.hands import HAND_CONNECTIONS

# 默认优先使用的设备（2K USB Camera 的采集节点）
DEFAULT_DEVICES = ["/dev/video2", "/dev/video4", "/dev/video0"]


def resolve_device(user_device=None):
    """
    解析要使用的摄像头设备路径。
    优先级：
        1. 命令行显式传入的设备
        2. 默认列表里第一个可用的设备（优先 2K USB Camera）
        3. 回退到索引 0（OpenCV 默认摄像头）
    :param user_device: 用户通过命令行传入的设备路径，可为 None。
    :return: OpenCV VideoCapture 可接受的设备标识（字符串路径或整数）。
    """
    if user_device:
        # 允许传 /dev/videoX，也允许直接传数字（如 0、2）
        if user_device.startswith("/dev/"):
            if not os.path.exists(user_device):
                raise FileNotFoundError(f"设备不存在: {user_device}")
            return user_device
        return int(user_device)

    for dev in DEFAULT_DEVICES:
        if os.path.exists(dev):
            print(f"[信息] 自动选择摄像头设备: {dev}")
            return dev

    print("[警告] 未找到默认设备，回退到索引 0")
    return 0


class GestureRecognizer:
    def __init__(
        self,
        model_path="hand_landmarker.task",
        maxHands=1,
        detectorCon=0.7,
        trackCon=0.7,
    ):
        base_options = python.BaseOptions(model_asset_path=model_path)
        # 注意：手势识别通常针对单手，因此 maxHands 默认为 1
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            num_hands=maxHands,
            min_hand_detection_confidence=detectorCon,
            min_hand_presence_confidence=trackCon,
        )
        self.landmarker = vision.HandLandmarker.create_from_options(options)

        self.tipIds = [4, 8, 12, 16, 20]
        self.lmList = []  # 用于存储像素坐标的列表

    def find_hands_and_landmarks(self, frame, draw=True):
        """
        在一帧中寻找手部，填充 lmList，并手动绘制关键点。
        :param frame: 输入的视频帧 (BGR 格式)。
        :param draw: 是否在图像上绘制。
        :return: 处理后的图像, 只有骨架的黑色图像。
        """
        # 重置关键点列表
        self.lmList = []

        img_RGB = cv.cvtColor(frame, cv.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=img_RGB)
        detection_result = self.landmarker.detect(mp_image)

        processed_frame = frame.copy()
        skeleton_img = np.zeros(frame.shape, np.uint8)

        # 如果检测到了手
        if detection_result.hand_landmarks:
            # 我们只处理检测到的第一只手，以确保手势识别逻辑的正确性
            hand_landmarks = detection_result.hand_landmarks[0]

            h, w, _ = frame.shape
            # 遍历这只手的所有关键点，将其ID和像素坐标存入 lmList
            for i, lm in enumerate(hand_landmarks):
                cx, cy = int(lm.x * w), int(lm.y * h)
                self.lmList.append([i, cx, cy])

            if draw:
                # 1. 绘制连接线
                for connection in HAND_CONNECTIONS:
                    start_idx = connection[0]
                    end_idx = connection[1]
                    if start_idx < len(self.lmList) and end_idx < len(self.lmList):
                        start_point = (
                            self.lmList[start_idx][1],
                            self.lmList[start_idx][2],
                        )
                        end_point = (
                            self.lmList[end_idx][1],
                            self.lmList[end_idx][2],
                        )
                        cv.line(processed_frame, start_point, end_point, (0, 255, 0), 2)
                        cv.line(skeleton_img, start_point, end_point, (0, 255, 0), 2)
                # 2. 绘制关键点
                for i in range(len(self.lmList)):
                    px, py = self.lmList[i][1], self.lmList[i][2]
                    cv.circle(processed_frame, (px, py), 6, (0, 0, 255), -1)
                    cv.circle(skeleton_img, (px, py), 6, (0, 0, 255), -1)

        return processed_frame, skeleton_img

    def get_dist(self, point1, point2):
        x1, y1 = point1
        x2, y2 = point2
        return math.sqrt((y1 - y2) ** 2 + (x1 - x2) ** 2)

    def calc_angle(self, pt1, pt2, pt3):
        point1 = (self.lmList[pt1][1], self.lmList[pt1][2])
        point2 = (self.lmList[pt2][1], self.lmList[pt2][2])
        point3 = (self.lmList[pt3][1], self.lmList[pt3][2])
        a = self.get_dist(point1, point2)
        b = self.get_dist(point2, point3)
        c = self.get_dist(point1, point3)
        try:
            radian = math.acos((a**2 + b**2 - c**2) / (2 * a * b))
            angle = radian / math.pi * 180
        except ValueError:
            angle = 0
        return abs(angle)

    def fingersUp(self):
        fingers = []
        # 大拇指：通过角度判断
        if (
            self.calc_angle(self.tipIds[0], self.tipIds[0] - 1, self.tipIds[0] - 2)
            > 150.0
        ) and (
            self.calc_angle(self.tipIds[0] - 1, self.tipIds[0] - 2, self.tipIds[0] - 3)
            > 150.0
        ):
            fingers.append(1)
        else:
            fingers.append(0)
        # 其余四个手指：通过指尖与指关节的y坐标判断
        for id in range(1, 5):
            if self.lmList[self.tipIds[id]][2] < self.lmList[self.tipIds[id] - 2][2]:
                fingers.append(1)
            else:
                fingers.append(0)
        return fingers

    def get_gesture(self):
        # 必须确保 lmList 不为空
        if not self.lmList:
            return ""

        fingers = self.fingersUp()
        totalFingers = fingers.count(1)
        gesture = ""

        if totalFingers == 0:
            gesture = "Zero"  # or "Fist"
        elif totalFingers == 1:
            if fingers[1] == 1:
                gesture = "One"
        elif totalFingers == 2:
            if fingers[1] == 1 and fingers[2] == 1:
                gesture = "Two"  # or "Victory"
            elif fingers[0] == 1 and fingers[4] == 1:
                gesture = "Six"  # or "Call me"
        elif totalFingers == 3:
            # OK 手势的特殊判断：拇指和食指指尖距离很近
            dist_ok = self.get_dist(
                (self.lmList[4][1], self.lmList[4][2]),
                (self.lmList[8][1], self.lmList[8][2]),
            )
            if fingers[0] == 1 and dist_ok < 50:
                gesture = "OK"
            else:
                gesture = "Three"
        elif totalFingers == 4:
            gesture = "Four"
        elif totalFingers == 5:
            gesture = "Five"  # or "Palm"

        # 可以添加一些更复杂的手势判断
        dist_thumb_up = self.get_dist(
            (self.lmList[4][1], self.lmList[4][2]),
            (self.lmList[5][1], self.lmList[5][2]),
        )
        if totalFingers == 1 and fingers[0] == 1 and dist_thumb_up > 80:
            gesture = "Thumb_up"

        return gesture

    def frame_combine(self, frame, src):
        frameH, frameW = frame.shape[:2]
        srcH, srcW = src.shape[:2]
        dst = np.zeros((max(frameH, srcH), frameW + srcW, 3), np.uint8)
        dst[:, :frameW] = frame[:, :]
        dst[:, frameW:] = src[:, :]
        return dst


def parse_args():
    parser = argparse.ArgumentParser(
        description="MediaPipe 手势识别（默认使用 2K USB Camera）"
    )
    parser.add_argument(
        "device",
        nargs="?",
        default=None,
        help="摄像头设备路径或索引，例如 /dev/video4 或 2。不传则自动选择 2K USB Camera。",
    )
    parser.add_argument(
        "--width", type=int, default=640, help="采集分辨率宽度，默认 640"
    )
    parser.add_argument(
        "--height", type=int, default=480, help="采集分辨率高度，默认 480"
    )
    parser.add_argument(
        "--model",
        default="hand_landmarker.task",
        help="手部地标模型文件路径，默认 hand_landmarker.task",
    )
    parser.add_argument("--max-hands", type=int, default=1, help="最大检测手数，默认 1")
    parser.add_argument(
        "--det-conf", type=float, default=0.75, help="检测置信度阈值，默认 0.75"
    )
    parser.add_argument(
        "--track-conf", type=float, default=0.7, help="跟踪置信度阈值，默认 0.7"
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    device = resolve_device(args.device)
    print(f"[信息] 使用设备: {device}")

    # Jetson 上建议显式指定 V4L2 后端，避免 GStreamer 管线协商问题
    capture = cv.VideoCapture(device, cv.CAP_V4L2)
    if not capture.isOpened():
        # 回退到默认后端
        capture = cv.VideoCapture(device)

    if not capture.isOpened():
        raise RuntimeError(f"无法打开摄像头设备: {device}")

    capture.set(cv.CAP_PROP_FRAME_WIDTH, args.width)
    capture.set(cv.CAP_PROP_FRAME_HEIGHT, args.height)
    print("摄像头FPS: ", capture.get(cv.CAP_PROP_FPS))

    pTime = cTime = 0
    # 初始化检测器
    recognizer = GestureRecognizer(
        model_path=args.model,
        detectorCon=args.det_conf,
        trackCon=args.track_conf,
        maxHands=args.max_hands,
    )

    while capture.isOpened():
        ret, frame = capture.read()
        if not ret:
            print("读取视频帧失败，退出。")
            break

        frame = cv.flip(frame, 1)

        # 查找手部并填充 lmList
        processed_frame, skeleton_img = recognizer.find_hands_and_landmarks(
            frame, draw=True
        )

        # 只有在 lmList 被成功填充后（即检测到手）才进行手势识别
        if recognizer.lmList:
            gesture = recognizer.get_gesture()
            cv.rectangle(processed_frame, (0, 0), (250, 50), (0, 255, 0), cv.FILLED)
            cv.putText(
                processed_frame,
                gesture,
                (10, 40),
                cv.FONT_HERSHEY_PLAIN,
                3,
                (255, 0, 255),
                3,
            )

        cTime = time.time()
        fps = 1 / (cTime - pTime) if (cTime - pTime) > 0 else 0
        pTime = cTime
        text = "FPS : " + str(int(fps))
        cv.putText(
            processed_frame,
            text,
            (450, 40),
            cv.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            2,
        )

        dist = recognizer.frame_combine(processed_frame, skeleton_img)
        cv.imshow("Gesture Recognition", dist)

        if cv.waitKey(1) & 0xFF == ord("q"):
            break

    capture.release()
    cv.destroyAllWindows()
