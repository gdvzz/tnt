# encoding: utf-8
import argparse
import os
import time

import cv2 as cv
import numpy as np

# 默认优先使用的设备（2K USB Camera 的采集节点）
DEFAULT_DEVICES = ["/dev/video2", "/dev/video4", "/dev/video0"]


def resolve_device(user_device=None):
    """
    解析要使用的摄像头设备路径。
    优先级：
        1. 命令行显式传入的设备
        2. 默认列表里第一个可用的设备（优先 2K USB Camera）
        3. 回退到索引 0（OpenCV 默认摄像头）
    :param user_device: 用户通过命令行传入的设备路径，可为 None。
    :return: OpenCV VideoCapture 可接受的设备标识（字符串路径或整数）。
    """
    if user_device:
        # 允许传 /dev/videoX，也允许直接传数字（如 0、2）
        if user_device.startswith("/dev/"):
            if not os.path.exists(user_device):
                raise FileNotFoundError(f"设备不存在: {user_device}")
            return user_device
        return int(user_device)

    for dev in DEFAULT_DEVICES:
        if os.path.exists(dev):
            print(f"[信息] 自动选择摄像头设备: {dev}")
            return dev

    print("[警告] 未找到默认设备，回退到索引 0")
    return 0


class FaceEyeDetection:
    def __init__(
        self,
        face_cascade_path="haarcascade_frontalface_default.xml",
        eye_cascade_path="haarcascade_eye.xml",
    ):
        # 检查并从本地加载模型文件
        if not os.path.exists(face_cascade_path) or not os.path.exists(
            eye_cascade_path
        ):
            print("错误：模型文件 (.xml) 未找到！")
            print(
                f"请确保 '{face_cascade_path}' 和 '{eye_cascade_path}' 与脚本在同一个目录下。"
            )
            exit(1)

        self.faceDetect = cv.CascadeClassifier(face_cascade_path)
        self.eyeDetect = cv.CascadeClassifier(eye_cascade_path)

    def detect_faces(self, frame):
        """检测图像中的人脸并绘制标记"""
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        # detectMultiScale返回一个矩形列表，每个矩形是 (x, y, w, h)
        faces = self.faceDetect.detectMultiScale(gray, 1.3, 5)
        for x, y, w, h in faces:
            frame = self.draw_face_bbox(frame, (x, y, w, h))
        return frame

    def detect_eyes(self, frame):
        """检测图像中的眼睛并绘制标记"""
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        eyes = self.eyeDetect.detectMultiScale(gray, 1.3, 5)
        for ex, ey, ew, eh in eyes:
            center = (int(ex + ew / 2), int(ey + eh / 2))
            radius = int(eh / 2)
            cv.circle(frame, center, radius, (0, 0, 255), 2)
        return frame

    def draw_face_bbox(self, frame, bbox, l=30, t=10):
        """在人脸周围绘制一个带装饰性边框的矩形"""
        x, y, w, h = bbox
        x1, y1 = x + w, y + h
        # 主矩形
        cv.rectangle(frame, (x, y), (x1, y1), (255, 0, 255), 2)
        # 左上角
        cv.line(frame, (x, y), (x + l, y), (255, 0, 255), t)
        cv.line(frame, (x, y), (x, y + l), (255, 0, 255), t)
        # 右上角
        cv.line(frame, (x1, y), (x1 - l, y), (255, 0, 255), t)
        cv.line(frame, (x1, y), (x1, y + l), (255, 0, 255), t)
        # 左下角
        cv.line(frame, (x, y1), (x + l, y1), (255, 0, 255), t)
        cv.line(frame, (x, y1), (x, y1 - l), (255, 0, 255), t)
        # 右下角
        cv.line(frame, (x1, y1), (x1 - l, y1), (255, 0, 255), t)
        cv.line(frame, (x1, y1), (x1, y1 - l), (255, 0, 255), t)
        return frame


def parse_args():
    parser = argparse.ArgumentParser(
        description="Haar 级联人脸/眼睛检测（默认使用 2K USB Camera）"
    )
    parser.add_argument(
        "device",
        nargs="?",
        default=None,
        help="摄像头设备路径或索引，例如 /dev/video4 或 2。不传则自动选择 2K USB Camera。",
    )
    parser.add_argument(
        "--width", type=int, default=640, help="采集分辨率宽度，默认 640"
    )
    parser.add_argument(
        "--height", type=int, default=480, help="采集分辨率高度，默认 480"
    )
    parser.add_argument(
        "--face-cascade",
        default="haarcascade_frontalface_default.xml",
        help="人脸检测模型文件路径",
    )
    parser.add_argument(
        "--eye-cascade",
        default="haarcascade_eye.xml",
        help="眼睛检测模型文件路径",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    device = resolve_device(args.device)
    print(f"[信息] 使用设备: {device}")

    # Jetson 上建议显式指定 V4L2 后端，避免 GStreamer 管线协商问题
    capture = cv.VideoCapture(device, cv.CAP_V4L2)
    if not capture.isOpened():
        # 回退到默认后端
        capture = cv.VideoCapture(device)

    if not capture.isOpened():
        raise RuntimeError(f"无法打开摄像头设备: {device}")

    capture.set(cv.CAP_PROP_FRAME_WIDTH, args.width)
    capture.set(cv.CAP_PROP_FRAME_HEIGHT, args.height)
    print("摄像头FPS: ", capture.get(cv.CAP_PROP_FPS))

    pTime, cTime = 0, 0

    # 初始化检测器
    face_eye_detector = FaceEyeDetection(
        face_cascade_path=args.face_cascade,
        eye_cascade_path=args.eye_cascade,
    )

    content = ["face", "eye", "face_eye"]
    content_index = 0

    while capture.isOpened():
        ret, frame = capture.read()
        if not ret:
            print("读取视频帧失败，退出。")
            break

        frame = cv.flip(frame, 1)  # 添加翻转，使其像镜子一样

        # -- 模式切换逻辑 --
        action = cv.waitKey(1) & 0xFF
        if action == ord("f") or action == ord("F"):
            content_index = (content_index + 1) % len(content)
            print(f"模式切换到: {content[content_index]}")

        # -- 根据模式执行检测 --
        mode = content[content_index]
        if mode == "face":
            frame = face_eye_detector.detect_faces(frame)
        elif mode == "eye":
            frame = face_eye_detector.detect_eyes(frame)
        elif mode == "face_eye":
            # 先检测人脸，再检测眼睛，可以稍微提高眼睛检测的准确性
            frame = face_eye_detector.detect_faces(frame)
            frame = face_eye_detector.detect_eyes(frame)

        if action == ord("q") or action == ord("Q"):
            break

        # -- 计算并显示FPS --
        cTime = time.time()
        fps = 1 / (cTime - pTime) if (cTime - pTime) > 0 else 0
        pTime = cTime
        text = f"FPS: {int(fps)} Mode: {mode}"
        cv.putText(frame, text, (20, 30), cv.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        cv.imshow("Face and Eye Detection", frame)

    capture.release()
    cv.destroyAllWindows()
