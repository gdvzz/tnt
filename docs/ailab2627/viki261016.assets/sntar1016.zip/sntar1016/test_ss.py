from openai import OpenAI

client = OpenAI(
    base_url="https://token.sensenova.cn/v1",
    api_key="sk-GuQRzzfULhVuK3JcQtqQLQiZ5A14x4sK",
)

resp = client.chat.completions.create(
    model="sensenova-6.8-flash-lite",
    messages=[{"role": "user", "content": "Hello!"}],
)

print(resp.choices[0].message.content)
