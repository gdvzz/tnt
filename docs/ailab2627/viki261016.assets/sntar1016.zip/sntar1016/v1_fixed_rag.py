# v1_fixed_rag.py
"""
V1 固定 RAG：每次提问都无条件检索，直接注入 Prompt。
"""

from core import retrieve, chat

SYSTEM_PROMPT = """你是一个旅游助手。根据提供的知识库片段回答用户问题。
如果知识库没有相关信息，如实告知，不要编造。
回答要具体、可执行，包含价格、时间、避坑提示。"""


def ask(query: str, verbose: bool = False) -> str:
    docs = retrieve(query, k=3)
    context = "\n\n".join(f"[片段{i+1}] {d['content']}" for i, d in enumerate(docs))

    if verbose:
        print(f"\n[V1 检索到 {len(docs)} 条片段]")

    prompt = f"""知识库片段：
{context}

用户问题：{query}

请基于以上片段回答。"""

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": prompt},
    ]
    resp = chat(messages, temperature=0.3)
    return resp["content"]


if __name__ == "__main__":
    print("=" * 55)
    print("  V1 固定 RAG｜Jetson Orin NX｜覆盖：无锡/厦门/杭州/西安")
    print("=" * 55)
    while True:
        q = input("\n你：").strip()
        if q.lower() == "q":
            break
        if not q:
            continue
        print(f"\n🤖 V1：{ask(q, verbose=True)}")
