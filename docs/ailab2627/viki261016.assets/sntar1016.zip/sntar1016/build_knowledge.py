# build_knowledge.py
"""
构建向量库。优化版：
- 清空前提示旧数据统计
- 显示进度百分比
- 汇总每城市结果
- 支持 --force 跳过确认
"""
import os
import sys
from core import embed, get_collection

KNOWLEDGE_FOLDER = "./knowledge"
CHUNK_SIZE = 300
CHUNK_OVERLAP = 50


def split_text(text: str, size: int, overlap: int) -> list:
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    for p in paragraphs:
        if len(p) <= size:
            chunks.append(p)
        else:
            sentences = p.replace("。", "。\n").split("\n")
            buf = ""
            for s in sentences:
                if len(buf) + len(s) <= size:
                    buf += s
                else:
                    if buf:
                        chunks.append(buf.strip())
                    buf = s
            if buf:
                chunks.append(buf.strip())
    overlapped = []
    for i, c in enumerate(chunks):
        if i > 0:
            tail = chunks[i - 1][-overlap:] if len(chunks[i - 1]) > overlap else chunks[i - 1]
            overlapped.append(tail + c)
        else:
            overlapped.append(c)
    return overlapped


def inspect_existing(coll) -> dict:
    """统计现有向量库的内容分布。"""
    existing = coll.get()
    if not existing["ids"]:
        return {"total": 0, "cities": {}}

    cities = {}
    for meta in existing["metadatas"]:
        city = (meta or {}).get("city", "unknown")
        cities[city] = cities.get(city, 0) + 1

    return {"total": len(existing["ids"]), "cities": cities}


def clear_collection(coll, force: bool = False) -> None:
    """清空向量库，带提示和确认。"""
    info = inspect_existing(coll)

    if info["total"] == 0:
        print("📦 向量库当前为空，无需清空")
        return

    # 提示旧数据
    print(f"📦 检测到向量库已有数据：共 {info['total']} 个 chunk")
    for city, cnt in sorted(info["cities"].items()):
        print(f"     · {city}: {cnt} 个")

    # 确认
    if not force:
        answer = input("⚠️  是否清空并重建？(y/N) ").strip().lower()
        if answer not in ("y", "yes"):
            print("❌ 已取消")
            sys.exit(0)

    # 清空
    existing = coll.get()
    coll.delete(ids=existing["ids"])
    print("🗑️  旧数据已清空\n")


def build(force: bool = False):
    print("=" * 55)
    print("  构建旅游知识库向量库")
    print("=" * 55)

    coll = get_collection()

    # ---------- 清空（带提示）----------
    clear_collection(coll, force=force)

    # ---------- 加载知识库文件 ----------
    files = [f for f in sorted(os.listdir(KNOWLEDGE_FOLDER)) if f.endswith(".txt")]
    if not files:
        print(f"❌ {KNOWLEDGE_FOLDER} 目录下没有 .txt 文件")
        sys.exit(1)

    print(f"📚 待处理知识库：{len(files)} 个文件")
    for f in files:
        print(f"     · {f}")
    print()

    # ---------- 逐个城市处理 ----------
    total = 0
    summary = []
    all_chunks = []  # (city, idx, chunk)

    # 先切分全部，方便算总进度
    for fname in files:
        city = fname.replace(".txt", "")
        path = os.path.join(KNOWLEDGE_FOLDER, fname)
        with open(path, encoding="utf-8") as f:
            text = f.read()
        chunks = split_text(text, CHUNK_SIZE, CHUNK_OVERLAP)
        all_chunks.append((city, fname, chunks))
        summary.append((city, len(chunks)))

    grand_total = sum(n for _, _, chunks in all_chunks for n in [len(chunks)])
    print(f"✂️  共切分 {grand_total} 个 chunk，开始向量化...\n")

    # 向量化 + 入库
    for city, fname, chunks in all_chunks:
        print(f"[{city}] {len(chunks)} 个 chunk")
        for i, chunk in enumerate(chunks):
            emb = embed(chunk)
            doc_id = f"{city}_{i}"
            coll.add(
                documents=[chunk],
                embeddings=[emb],
                ids=[doc_id],
                metadatas=[{"city": city, "source": fname, "chunk_idx": i}],
            )
            total += 1
            # 全局进度
            pct = total / grand_total * 100
            bar_len = 30
            filled = int(bar_len * total / grand_total)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f"     [{bar}] {total}/{grand_total} ({pct:.1f}%)", end="\r")
        print(f"     [{('█' * bar_len)}] {total}/{grand_total} (100.0%)  ✅ {city} 完成")

    # ---------- 汇总 ----------
    print()
    print("=" * 55)
    print("  ✅ 向量库构建完成")
    print("=" * 55)
    for city, cnt in summary:
        print(f"  · {city:<12} {cnt:>3} 个 chunk")
    print(f"  {'-' * 30}")
    print(f"  · {'合计':<12} {total:>3} 个 chunk")
    print(f"\n  存储位置：chroma_db/")
    print("=" * 55)


if __name__ == "__main__":
    force = "--force" in sys.argv or "-f" in sys.argv
    build(force=force)
