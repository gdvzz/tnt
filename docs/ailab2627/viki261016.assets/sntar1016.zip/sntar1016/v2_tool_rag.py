# v2_tool_rag.py
"""
V2 Tool-RAG：RAG 封装成工具，Agent 通过 function calling 自主判断何时调用。
"""
import json
from core import chat
from tools import TOOLS_SCHEMA, execute_tool

LLM_MODEL = "qwen2.5:3b"
MAX_HISTORY = 6
MAX_TOOL_ROUNDS = 5

SYSTEM_PROMPT = """你是一个专业的学生旅游规划智能体，采用 ReAct 模式工作。

工具使用规则：
1. 涉及景点门票、预约方式、学生优惠、开放时间、避坑提醒时，必须调用 search_travel_knowledge。
2. 规划行程前，先调用 get_top_attractions 拿到景点清单，再针对关键景点调用 RAG 检索细节。
3. 天气、美食、住宿按需调用对应工具。
4. 最多连续调用 5 轮工具，信息足够后直接输出完整方案。
5. 最终输出结构化按天行程，含：每日路线、用餐建议、住宿参考、学生提示、避坑提醒。
6. 回答要简洁。同一信息只说一次，不要重复。不要复述工具返回的原文，用自己的话整合。
7. 只回答用户问的内容。用户没问的信息不要主动展开，除非与问题直接相关。"""


class V2ToolRAGAgent:
    def __init__(self):
        self.history = []

    def _truncate(self):
        if len(self.history) > MAX_HISTORY * 2:
            self.history = self.history[-MAX_HISTORY * 2:]

    def run(self, query: str, verbose: bool = False) -> str:
        self._truncate()
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(self.history)
        messages.append({"role": "user", "content": query})

        for r in range(MAX_TOOL_ROUNDS):
            try:
                resp = chat(messages, model=LLM_MODEL, tools=TOOLS_SCHEMA, temperature=0.1)
            except Exception as e:
                return f"⚠️ 模型调用失败：{e}"

            tool_calls = resp.get("tool_calls") or []
            if not tool_calls:
                final = resp.get("content", "")
                self.history.append({"role": "user", "content": query})
                self.history.append({"role": "assistant", "content": final})
                return final

            messages.append(resp)
            for tc in tool_calls:
                fn_info = tc.get("function", {})
                name = fn_info.get("name")
                args = fn_info.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}

                if verbose:
                    print(f"  [V2 调用工具] {name}({args})")

                result = execute_tool(name, args)
                messages.append({"role": "tool", "content": result})

        try:
            return chat(messages, model=LLM_MODEL, temperature=0.1).get("content", "")
        except Exception as e:
            return f"⚠️ 达到最大轮次：{e}"


if __name__ == "__main__":
    agent = V2ToolRAGAgent()
    print("=" * 55)
    print("  V2 Tool-RAG｜Jetson Orin NX｜覆盖：无锡/厦门/杭州/西安")
    print("=" * 55)
    while True:
        q = input("\n你：").strip()
        if q.lower() == "q":
            break
        if not q:
            continue
        print(f"\n🤖 V2：{agent.run(q, verbose=True)}")
