from core import retrieve

for q in [
    "拈花湾 学生票 开放时间 预约",
    "无锡 门票 预约 学生优惠",
    "拈花湾 门票",
    "拈花湾",
]:
    print(f"\n=== query: {q} ===")
    docs = retrieve(q, k=4, city="wuxi")
    print(f"  无过滤 k=4 → {len(docs)} 条")
    if docs:
        for d in docs:
            print(f"    · {d['content'][:50]}")

    docs2 = retrieve(q, k=4, city=None)
    print(f"  无过滤 k=4 → {len(docs2)} 条")

    docs3 = retrieve(q, k=10, city="wuxi")
    print(f"  city过滤 k=10 → {len(docs3)} 条")
