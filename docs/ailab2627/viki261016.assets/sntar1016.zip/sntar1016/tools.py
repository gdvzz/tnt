# tools.py
"""
工具定义：普通函数 + 手写 function calling schema。
v3.7: search_travel_knowledge 支持 city 参数，按城市过滤。
"""
import json
from core import retrieve

# 中文城市名 → 拼音（与 build_knowledge.py 存的 metadata 一致）
CITY_PINYIN = {
    "无锡": "wuxi",
    "厦门": "xiamen",
    "杭州": "hangzhou",
    "西安": "xi_an",
}


# ==================== 工具实现 ====================
def get_weather(city: str, date: str = "today") -> dict:
    mock = {
        "无锡": {"condition": "多云转晴，18-26℃，东南风3级", "tip": "适合户外，早晚加薄外套"},
        "厦门": {"condition": "多云，24-30℃，偶有微风", "tip": "海边注意补水，随身带折叠伞"},
        "杭州": {"condition": "晴，22-28℃", "tip": "带防晒、薄外套"},
        "西安": {"condition": "阴天，16-22℃", "tip": "早晚偏凉加衣"},
    }
    info = mock.get(city, {"condition": "暂无数据", "tip": "出行前自行核实"})
    return {"city": city, "date": date, **info}


def get_top_attractions(city: str) -> dict:
    attr = {
        "无锡": ["鼋头渚", "灵山大佛", "拈花湾", "惠山古镇", "无锡博物院", "南长街"],
        "厦门": ["鼓浪屿", "沙坡尾", "南普陀寺", "环岛路", "厦门大学"],
        "杭州": ["西湖环湖", "灵隐寺飞来峰", "龙井村", "九溪烟树", "河坊街"],
        "西安": ["秦始皇兵马俑", "陕西历史博物馆", "大唐不夜城", "回民街", "洒金桥"],
    }
    return {"city": city, "attractions": attr.get(city, ["暂无数据"])}


def get_food_recommend(city: str) -> dict:
    food = {
        "无锡": ["无锡小笼包", "酱排骨", "开洋馄饨", "玉兰饼", "太湖三白"],
        "厦门": ["沙茶面", "海蛎煎", "土笋冻", "花生汤", "八市海肠捞饭"],
        "杭州": ["片儿川", "葱包烩", "东坡肉", "西湖醋鱼", "定胜糕"],
        "西安": ["腊汁肉夹馍", "牛羊肉泡馍", "甑糕", "肉丸胡辣汤", "麻酱凉皮"],
    }
    return {"city": city, "foods": food.get(city, ["暂无数据"])}


def get_hotel_suggest(city: str, budget: str = "中等") -> dict:
    tips = {
        "无锡": "推荐三阳广场/清名桥地铁站周边",
        "厦门": "首选思明区中山路附近，出门即小吃街",
        "杭州": "推荐凤起路/定安路地铁口附近",
        "西安": "推荐钟楼/南门附近，地铁便利",
    }
    return {
        "city": city, "budget": budget,
        "suggest": f"建议选地铁口或景区附近；{budget}档位优先连锁酒店或学生友好民宿，节假日提前预订。{tips.get(city, '')}",
    }


def search_travel_knowledge(query: str, city: str = None) -> dict:
    """
    【RAG工具】检索本地旅游知识库。
    city：必填，用于按城市过滤（避免跨城市召回）。
    """
    city_pinyin = CITY_PINYIN.get(city) if city else None
    docs = retrieve(query, k=3, city=city_pinyin)
    return {
        "rag_query": query,
        "city": city,
        "filtered_by": city_pinyin,
        "retrieved": [d["content"] for d in docs] if docs else [],
        "note": "知识库中未找到相关信息" if not docs else None,
    }


TOOL_REGISTRY = {
    "get_weather": get_weather,
    "get_top_attractions": get_top_attractions,
    "get_food_recommend": get_food_recommend,
    "get_hotel_suggest": get_hotel_suggest,
    "search_travel_knowledge": search_travel_knowledge,
}


# ==================== Function Calling Schema ====================
def _schema(name: str, desc: str, properties: dict, required: list) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
    }


TOOLS_SCHEMA = [
    _schema("get_weather", "查询城市指定日期的天气与出行提示。",
            {"city": {"type": "string"}, "date": {"type": "string"}}, ["city"]),
    _schema("get_top_attractions", "查询城市热门景点列表。",
            {"city": {"type": "string"}}, ["city"]),
    _schema("get_food_recommend", "查询城市特色美食推荐。",
            {"city": {"type": "string"}}, ["city"]),
    _schema("get_hotel_suggest", "按预算给住宿建议。",
            {"city": {"type": "string"}, "budget": {"type": "string"}}, ["city"]),
    _schema("search_travel_knowledge",
            "【RAG工具·必须调用】检索本地旅游知识库，获取门票价格、预约方式、开放时间、学生优惠、避坑贴士。"
            "**务必传入 city 参数限定城市，否则会检索到其他城市的信息**。",
            {
                "query": {"type": "string", "description": "自然语言关键词，如'灵山大佛学生票'"},
                "city": {"type": "string", "description": "城市名，如'无锡'，必须传入"},
            },
            ["query", "city"]),
]


def execute_tool(name: str, args: dict) -> str:
    fn = TOOL_REGISTRY.get(name)
    if fn is None:
        return json.dumps({"error": f"未知工具 {name}"}, ensure_ascii=False)
    try:
        result = fn(**args)
        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": f"工具执行失败：{e}"}, ensure_ascii=False)
