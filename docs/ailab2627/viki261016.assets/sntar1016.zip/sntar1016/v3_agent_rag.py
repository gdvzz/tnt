# v3_agent_rag.py
"""
V3 Agent-RAG  v5.0
修复：
  - 补回 REFLECTION_PROMPT（v4.x 丢失）
  - SYSTEM_PROMPT 的 ⚡ 标注规则改为：仅"全通用知识"才标注，部分知识库内容不标
  - core.py chat 加 429 自动重试
保留 v4.12 所有功能
"""

import json
import re
import sys
import time
import os
import argparse
import unicodedata
from datetime import datetime
from core import retrieve, chat
from tools import TOOLS_SCHEMA, execute_tool, TOOL_REGISTRY, CITY_PINYIN

LLM_MODEL = "sensenova-6.8-flash-lite"
MAX_HISTORY = 6
MAX_TOOL_ROUNDS = 5
MAX_REFLECTION_ROUNDS = 3

KNOWN_CITIES = ["无锡", "厦门", "杭州", "西安"]

SCENE_TO_CITY = {
    # 无锡
    "鼋头渚": "无锡",
    "灵山大佛": "无锡",
    "灵山胜境": "无锡",
    "拈花湾": "无锡",
    "惠山古镇": "无锡",
    "寄畅园": "无锡",
    "无锡博物院": "无锡",
    "南长街": "无锡",
    "南禅寺": "无锡",
    "太湖仙岛": "无锡",
    "天下第二泉": "无锡",
    # 厦门
    "鼓浪屿": "厦门",
    "厦门大学": "厦门",
    "南普陀寺": "厦门",
    "沙坡尾": "厦门",
    "环岛路": "厦门",
    "八市": "厦门",
    "曾厝垵": "厦门",
    "厦鼓码头": "厦门",
    "三丘田": "厦门",
    # 杭州
    "西湖": "杭州",
    "灵隐寺": "杭州",
    "飞来峰": "杭州",
    "雷峰塔": "杭州",
    "龙井村": "杭州",
    "九溪烟树": "杭州",
    "河坊街": "杭州",
    "岳庙": "杭州",
    "三潭印月": "杭州",
    "苏堤": "杭州",
    "白堤": "杭州",
    "断桥": "杭州",
    "永福禅寺": "杭州",
    # 西安
    "兵马俑": "西安",
    "秦始皇兵马俑": "西安",
    "秦始皇帝陵博物院": "西安",
    "陕西历史博物馆": "西安",
    "陕历博": "西安",
    "大唐不夜城": "西安",
    "回民街": "西安",
    "洒金桥": "西安",
    "华清池": "西安",
    "大雁塔": "西安",
    "小雁塔": "西安",
    "西安博物院": "西安",
    "钟楼": "西安",
    "鼓楼": "西安",
}

TOOL_INFO = {
    "get_weather": ("查天气", "模拟"),
    "get_top_attractions": ("查热门景点", "模拟"),
    "get_food_recommend": ("查美食推荐", "模拟"),
    "get_hotel_suggest": ("查住宿建议", "模拟"),
    "search_travel_knowledge": ("RAG检索知识库", "真实"),
}


# ============================================================
#  输出工具
# ============================================================
def _fmt_ms(ms: float) -> str:
    return f"{ms/1000:.2f}s" if ms >= 1000 else f"{ms:.0f}ms"


def _truncate(s: str, n: int = 100) -> str:
    s = str(s).replace("\n", " ")
    return s if len(s) <= n else s[:n] + "..."


def _tool_label(name: str) -> str:
    cn, kind = TOOL_INFO.get(name, (name, "未知"))
    icon = "🔎" if kind == "真实" else "🎭"
    return f"{icon}{cn} [{kind}]"


def emit(icon: str, name: str, ms: float, note: str = "", level: int = 0):
    indent = "  " * level
    line = f"{indent}{icon} {name:<22} {_fmt_ms(ms):>8}"
    if note:
        line += f"   {note}"
    print(line, flush=True)


def hr(width: int = 64):
    print("─" * width, flush=True)


def _display_width(s: str) -> int:
    w = 0
    for ch in s:
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            w += 2
        else:
            w += 1
    return w


def _pad_right(s: str, target_width: int) -> str:
    pad = target_width - _display_width(s)
    return s + " " * max(pad, 0)


def box_top(width: int = 64, title: str = ""):
    if title:
        title_disp = _display_width(title)
        pad = width - title_disp - 6
        left = max(pad // 2, 0)
        right = max(pad - left, 0)
        print("╔" + "═" * left + f"  {title}  " + "═" * right + "╗", flush=True)
    else:
        print("╔" + "═" * (width - 2) + "╗", flush=True)


def box_line(text: str, width: int = 64):
    max_len = width - 4
    if _display_width(text) > max_len:
        truncated = ""
        w = 0
        limit = max_len - 3
        for ch in text:
            cw = 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
            if w + cw > limit:
                break
            truncated += ch
            w += cw
        text = truncated + "..."
    print("║ " + _pad_right(text, max_len) + " ║", flush=True)


def box_bottom(width: int = 64):
    print("╚" + "═" * (width - 2) + "╝", flush=True)


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            s.write(data)
            s.flush()

    def flush(self):
        for s in self.streams:
            s.flush()


# ============================================================
#  Prompt（v5.0: ⚡ 标注规则简化）
# ============================================================
SYSTEM_PROMPT = """你是一个专业的学生旅游规划智能体，采用 ReAct 模式工作。

【信息源优先级 · 必须严格遵守】
1. **第一优先级：知识库信息**。景点名称、门票价格、开放时间、预约方式，凡是知识库有的，**必须严格来自【知识库真实信息】或工具返回结果**。
2. **第二优先级：通用知识**。知识库没有的信息，可以用你的通用知识回答，规则如下：
   - **只有当整篇回答完全没有任何知识库内容时**（即全部用通用知识回答），才在回答**最后一行**加简短说明：
     `—— ⚡ 以上为通用知识，非本地知识库，建议以官方为准 ——`
   - **如果回答中任何一部分来自知识库**：**不加任何标注**，也不要给个别段落加 ⚡ 前缀。
   - **不要**在正文中插入长段警告或打断阅读。
3. **绝对禁止编造景点名**。不确定存在的景点不要写。
4. **只能规划用户指定城市的景点**，不要提其他城市。
5. **预算计算必须使用知识库中的真实票价**，知识库没有的票价不要臆造。
6. 如果实际花费明显低于用户预算（低于 70%），主动给出**预算升级建议**。

【⚠️ 强制调 RAG 的场景 · 不得跳过】
以下问题**必须先调用 search_travel_knowledge 核实**，**不得凭通用知识直接回答**：
1. 涉及无锡、厦门、杭州、西安任一城市的**任何景点问题**——**包括"是/否"类简单问题**（如"周一开门吗""要预约吗"）。
2. 涉及门票价格、学生优惠、开放时间、预约方式、避坑信息。
3. **不要因为"问题看起来简单"就跳过 RAG**。例如"陕西历史博物馆周一开门吗"看似简单，但必须查知识库才知道准确答案。
4. 如果知识库里有该景点信息，**优先使用知识库**，即使你"记得"通用答案。

【工具使用规则】
1. 涉及景点门票、预约、学生优惠、开放时间时，必须调用 search_travel_knowledge。
2. **调用 search_travel_knowledge 时必须传入 city 参数**（如 city='无锡'）。
3. 规划行程前，先调用 get_top_attractions 拿景点清单。
4. 天气、美食、住宿按需调用。
5. 最多 5 轮工具调用。

【输出格式（仅规划类问题适用）】

### 第一天
- 【路线】具体景点顺序 + 交通方式
- 【用餐】早/午/晚推荐
- 【住宿】区域建议
- 【学生提示 & 避坑】学生优惠、预约提醒、注意事项

### 第二天
（同第一天格式，以此类推）

【通用规则】
- 每天 4 项必须齐全（路线/用餐/住宿/学生提示）
- 必须是具体的景点名，不要笼统描述
- 同一信息只说一次，不要重复
- 回答简洁，不要客套话
"""

REFLECTION_PROMPT = """检查以下行程是否存在**明确的具体问题**。严格输出 JSON。

用户需求：{user_query}
行程草案：
{draft}

只检查以下 3 类硬性问题：
1. 景点不存在或明显编造
2. 同一天景点跨城
3. 关键信息缺失（如没提学生票或预约）

符合则输出 {{"has_issue": false, "issues": []}}
否则输出 {{"has_issue": true, "issues": [{{"type": "类型", "detail": "描述"}}]}}

只输出 JSON，不要任何其他文字。"""

FIX_PROMPT = """根据审核意见，**只输出需要补充的条目**（不重写整个行程）。

【当前行程】
{draft}

【审核意见】
{issues_text}

【要求】
- 每条以 "- " 开头，简洁
- 最多 5 条
- 不要重复行程中已有的内容
- 只输出条目，不要其他解释
"""


# ============================================================
#  Rerank
# ============================================================
def _keyword_rerank(query: str, docs: list, top_k: int = 3) -> list:
    scene_names = set()
    for d in docs:
        scene_names.update(re.findall(r"【([^】]+)】", d["content"]))

    mentioned = []
    for s in scene_names:
        clean = re.sub(r"[（(].*?[)）]", "", s).strip()
        if not clean:
            continue
        if clean in query or (len(clean) >= 3 and clean[:3] in query):
            mentioned.append(s)

    if mentioned:
        filtered = [d for d in docs if any(s in d["content"] for s in mentioned)]
        if filtered:
            if len(filtered) < top_k:
                keywords = re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]+", query)
                used_ids = {id(d) for d in filtered}
                scored = []
                for d in docs:
                    if id(d) in used_ids:
                        continue
                    hits = sum(1 for kw in keywords if kw in d.get("content", ""))
                    scored.append((hits, d))
                scored.sort(key=lambda x: -x[0])
                for _, d in scored:
                    filtered.append(d)
                    if len(filtered) >= top_k:
                        break
            return filtered[:top_k]

    keywords = re.findall(r"[\u4e00-\u9fa5]{2,}|[a-zA-Z]+", query)
    scored = []
    for i, d in enumerate(docs):
        content = d.get("content", "")
        hits = sum(1 for kw in keywords if kw in content)
        scored.append((i, hits))
    scored.sort(key=lambda x: (-x[1], x[0]))
    return [docs[i] for i, _ in scored[:top_k]]


def rag_retrieve(query: str, city: str = None) -> dict:
    city_pinyin = CITY_PINYIN.get(city) if city else None
    docs = retrieve(query, k=20, city=city_pinyin)
    if not docs:
        return {"rag_query": query, "city": city, "retrieved": [], "note": "未找到"}
    top_docs = _keyword_rerank(query, docs, top_k=3)
    return {
        "rag_query": query,
        "city": city,
        "retrieved": [d["content"] for d in top_docs],
    }


# ============================================================
#  Agent
# ============================================================
class V3AgentRAG:
    def __init__(self, enable_reflection: bool = True, enable_ask: bool = True):
        self.history = []
        self.context = {"city": None, "days": None, "budget": None}
        self.enable_reflection = enable_reflection
        self.enable_ask = enable_ask

        self._rag_cache = {}

        TOOL_REGISTRY["search_travel_knowledge"] = (
            lambda query, city=None: self._cached_rag(query, city=city)
        )

    def _cached_rag(self, query: str, city: str = None) -> dict:
        key = f"{city or ''}|{query.strip()}"
        if key in self._rag_cache:
            return self._rag_cache[key]
        result = rag_retrieve(query, city=city)
        self._rag_cache[key] = result
        return result

    def _extract_slots(self, query: str) -> dict:
        t0 = time.perf_counter()

        detected_city = None
        for city in KNOWN_CITIES:
            if city in query:
                detected_city = city
                break

        if not detected_city:
            for scene, city in SCENE_TO_CITY.items():
                if scene in query:
                    detected_city = city
                    break

        days = None
        m = re.search(r"([一二三四五六七八九十两\d]+)\s*[日天]", query)
        if m:
            num_str = m.group(1)
            cn_map = {
                "一": 1,
                "二": 2,
                "两": 2,
                "三": 3,
                "四": 4,
                "五": 5,
                "六": 6,
                "七": 7,
                "八": 8,
                "九": 9,
                "十": 10,
            }
            if num_str.isdigit():
                days = int(num_str)
            elif num_str in cn_map:
                days = cn_map[num_str]

        budget = None
        m = re.search(r"预算\s*(\d+)", query)
        if m:
            budget = m.group(1)
        else:
            m = re.search(r"(\d+)\s*元", query)
            if m:
                budget = m.group(1)

        emit(
            "🏷️",
            "槽位提取",
            (time.perf_counter() - t0) * 1000,
            f"city={detected_city}  days={days}  budget={budget}",
        )
        return {"city": detected_city, "days": days, "budget": budget}

    def _should_ask_city(self, query: str) -> bool:
        if not self.enable_ask:
            return False
        planning_kw = ["规划", "行程", "安排", "路线", "日游", "旅游", "玩"]
        if not any(k in query for k in planning_kw):
            return False

        for city in KNOWN_CITIES:
            if city in query:
                return False

        for scene in SCENE_TO_CITY:
            if scene in query:
                return False

        last_user_msg = None
        for msg in reversed(self.history):
            if msg.get("role") == "user":
                last_user_msg = msg.get("content", "")
                break
        if last_user_msg:
            if any(city in last_user_msg for city in KNOWN_CITIES):
                return False
            if any(scene in last_user_msg for scene in SCENE_TO_CITY):
                return False

        return self.context["city"] is None

    def _truncate(self):
        if len(self.history) > MAX_HISTORY * 2:
            self.history = self.history[-MAX_HISTORY * 2 :]

    def _react(self, query: str, city: str = None, extra_context: str = None) -> str:
        t_start = time.perf_counter()

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(self.history)

        if extra_context:
            user_content = f"""【知识库真实信息 —— 有则严格使用；完全没有知识库内容时才在末尾标注 ⚡】
{extra_context}

【用户需求】
{query}"""
        else:
            user_content = query
        messages.append({"role": "user", "content": user_content})

        n_llm = 0
        n_tool = 0
        retry_count = 0

        for rnd in range(MAX_TOOL_ROUNDS):
            print(
                f"\n  ┌─ ReAct 第 {rnd + 1} 轮 ───────────────────────────────",
                flush=True,
            )

            try:
                t0 = time.perf_counter()
                resp = chat(
                    messages, model=LLM_MODEL, tools=TOOLS_SCHEMA, temperature=0.1
                )
                t_llm = (time.perf_counter() - t0) * 1000
                n_llm += 1
            except Exception as e:
                emit(
                    "🔄",
                    "ReAct 循环",
                    (time.perf_counter() - t_start) * 1000,
                    f"LLM 异常：{e}",
                )
                return f"⚠️ 模型调用失败：{e}"

            thought = (resp.get("content") or "").strip()
            tool_calls = resp.get("tool_calls") or []

            if thought:
                print(f"  │ 💭 Thought: {_truncate(thought, 120)}", flush=True)
            else:
                print(f"  │ 💭 Thought: (本轮无显式文本，直接发起工具调用)", flush=True)

            if not tool_calls:
                if not thought and retry_count < 2:
                    retry_count += 1
                    print(
                        f"  │ ⚠️  LLM 返回空 content，触发第 {retry_count} 次重试",
                        flush=True,
                    )
                    messages.append(resp)
                    messages.append(
                        {
                            "role": "user",
                            "content": "你上一条回复为空。请基于已有的【知识库真实信息】和用户需求，输出完整、具体的回答。",
                        }
                    )
                    continue

                if not thought:
                    print(
                        f"  │ ❌ 重试 {retry_count} 次仍为空，返回兜底提示", flush=True
                    )
                    fallback = (
                        "抱歉，本次生成出现异常（模型返回空内容）。"
                        "请重新描述你的问题，或换个角度提问。"
                    )
                    emit(
                        "🔄",
                        "ReAct 循环",
                        (time.perf_counter() - t_start) * 1000,
                        f"{n_llm} 轮 LLM  ·  {n_tool} 次工具  ❌ 空回答",
                    )
                    return fallback

                print(f"  │ 🎯 Final Answer（本轮无工具调用）", flush=True)
                print(
                    f"  └─ 耗时 {_fmt_ms(t_llm)}  ·  累计 {n_llm} 轮 LLM / {n_tool} 次工具",
                    flush=True,
                )
                emit(
                    "🔄",
                    "ReAct 循环",
                    (time.perf_counter() - t_start) * 1000,
                    f"{n_llm} 轮 LLM  ·  {n_tool} 次工具",
                )
                return thought

            print(
                f"  │ ▶️ Action: 发起 {len(tool_calls)} 个工具调用（LLM 耗时 {_fmt_ms(t_llm)}）",
                flush=True,
            )
            messages.append(resp)

            for tc in tool_calls:
                fn_info = tc.get("function", {})
                name = fn_info.get("name")
                args = fn_info.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}

                if name == "search_travel_knowledge" and city and not args.get("city"):
                    args["city"] = city

                args_str = json.dumps(args, ensure_ascii=False)
                print(
                    f"  │    🔧 {_tool_label(name)}({_truncate(args_str, 80)})",
                    flush=True,
                )

                t0 = time.perf_counter()
                result = execute_tool(name, args)
                t_tool = (time.perf_counter() - t0) * 1000
                n_tool += 1

                result_str = str(result)
                cached = " (缓存)" if t_tool < 1 else ""

                try:
                    parsed = json.loads(result_str)
                    if isinstance(parsed, dict) and "error" in parsed:
                        print(f"  │    ⚠️  工具错误：{parsed['error']}", flush=True)
                        messages.append({"role": "tool", "content": result})
                        continue

                    if name == "search_travel_knowledge":
                        n_docs = len(parsed.get("retrieved", []))
                        print(
                            f"  │    👀 Observation{cached}: 检索到 {n_docs} 条知识",
                            flush=True,
                        )
                        for j, doc in enumerate(parsed.get("retrieved", [])[:3], 1):
                            snippet = _truncate(doc, 80)
                            print(f"  │         [{j}] {snippet}", flush=True)
                    elif name == "get_top_attractions":
                        attrs = parsed.get("attractions", [])
                        print(
                            f"  │    👀 Observation{cached}: {len(attrs)} 个景点 → {', '.join(attrs[:6])}",
                            flush=True,
                        )
                    elif name == "get_food_recommend":
                        foods = parsed.get("foods", [])
                        print(
                            f"  │    👀 Observation{cached}: {len(foods)} 道美食 → {', '.join(foods[:5])}",
                            flush=True,
                        )
                    elif name == "get_weather":
                        cond = parsed.get("condition", "")
                        tip = parsed.get("tip", "")
                        print(
                            f"  │    👀 Observation{cached}: {cond}  {tip}", flush=True
                        )
                    elif name == "get_hotel_suggest":
                        sug = parsed.get("suggest", "")
                        print(
                            f"  │    👀 Observation{cached}: {_truncate(sug, 100)}",
                            flush=True,
                        )
                    else:
                        print(
                            f"  │    👀 Observation{cached}: {_truncate(result_str, 120)}",
                            flush=True,
                        )
                except (json.JSONDecodeError, TypeError):
                    print(
                        f"  │    👀 Observation{cached}: {_truncate(result_str, 120)}",
                        flush=True,
                    )

                messages.append({"role": "tool", "content": result})

            print(
                f"  └─ 本轮耗时 {_fmt_ms((time.perf_counter() - t_start))} 累计",
                flush=True,
            )

        try:
            resp = chat(messages, model=LLM_MODEL, temperature=0.1)
            content = (resp.get("content") or "").strip()
            emit(
                "🔄",
                "ReAct 循环",
                (time.perf_counter() - t_start) * 1000,
                f"{n_llm} 轮 LLM  ·  {n_tool} 次工具  ⚠️ 达上限",
            )
            return content or "抱歉，达到最大工具调用轮次。请简化问题重试。"
        except Exception as e:
            emit(
                "🔄",
                "ReAct 循环",
                (time.perf_counter() - t_start) * 1000,
                f"达上限且生成失败",
            )
            return f"⚠️ 达到最大轮次：{e}"

    def _quick_check(self, query: str, draft: str) -> list:
        issues = []
        planning_kw = ["规划", "行程", "安排", "路线", "日游", "旅游", "玩"]
        is_planning = any(k in query for k in planning_kw)

        if is_planning:
            if "第" not in draft or "天" not in draft:
                issues.append({"type": "结构", "detail": "行程未按天分节"})

        if "学生" in query and "学生" not in draft:
            issues.append(
                {
                    "type": "学生优惠",
                    "detail": "用户是学生党，但回答未提及学生票或学生优惠",
                }
            )

        if "门票" in draft and "预约" not in draft and "提前" not in draft:
            issues.append({"type": "预约", "detail": "回答涉及门票，但未提预约方式"})

        if is_planning and len(draft) < 200:
            issues.append({"type": "完整性", "detail": "行程过短，信息量不足"})

        return issues

    def _reflect(self, query: str, draft: str) -> dict:
        quick_issues = self._quick_check(query, draft)
        if not quick_issues:
            return {"has_issue": False, "issues": [], "_source": "rule"}

        print(f"  [规则预检发现 {len(quick_issues)} 个疑似问题，调用 LLM 深入检查]")
        try:
            resp = chat(
                [
                    {
                        "role": "user",
                        "content": REFLECTION_PROMPT.format(
                            user_query=query, draft=draft
                        ),
                    }
                ],
                model=LLM_MODEL,
                temperature=0.0,
            )
            text = str(resp.get("content", "")).strip()

            s, e = text.find("{"), text.rfind("}")
            if s != -1 and e != -1:
                try:
                    data = json.loads(text[s : e + 1])
                    if isinstance(data, dict) and "has_issue" in data:
                        data["_source"] = "llm"
                        return data
                except json.JSONDecodeError:
                    pass

            if re.search(r'"has_issue"\s*:\s*true', text):
                return {
                    "has_issue": True,
                    "issues": quick_issues,
                    "_source": "fallback",
                }

            return {"has_issue": True, "issues": quick_issues, "_source": "rule-only"}
        except Exception as ex:
            print(f"  ⚠️  reflect 异常：{type(ex).__name__}: {ex}")
            return {"has_issue": True, "issues": quick_issues, "_source": "rule-only"}

    def run(self, query: str, verbose: bool = False):
        t_run = time.perf_counter()
        self._truncate()

        print()
        hr()
        print(f"🎫 你：{query}")
        hr()

        slots = self._extract_slots(query)
        has_city_this_turn = slots.get("city") is not None

        if has_city_this_turn:
            self.context["city"] = slots["city"]
        else:
            if self._should_ask_city(query):
                self.context["city"] = None

        if slots.get("days"):
            self.context["days"] = slots["days"]
        if slots.get("budget"):
            self.context["budget"] = slots["budget"]

        if self._should_ask_city(query):
            emit("📍", "追问城市", (time.perf_counter() - t_run) * 1000)
            hr()
            return "请问您想去哪个城市呢？（目前知识库覆盖：无锡、厦门、杭州、西安）"

        t_pre = time.perf_counter()
        planning_kw = ["规划", "行程", "安排", "路线", "日游", "旅游", "玩"]
        is_planning = any(k in query for k in planning_kw)
        extra_context = None

        if is_planning and self.context["city"]:
            city = self.context["city"]

            attr_result = execute_tool("get_top_attractions", {"city": city})

            prefetch_query = f"{city} 门票 预约 学生优惠 开放时间 避坑"
            rag_result = self._cached_rag(prefetch_query, city=city)
            retrieved = rag_result.get("retrieved", [])

            extra_context = (
                f"【{city}热门景点列表】\n{attr_result}\n\n"
                f"【{city}详细知识】\n" + "\n\n".join(retrieved)
            )
            emit(
                "📚",
                "前置 RAG 检索",
                (time.perf_counter() - t_pre) * 1000,
                f"city={city}  → 注入 {len(retrieved)} 条知识到 prompt",
            )

        draft = self._react(
            query, city=self.context["city"], extra_context=extra_context
        )

        t_refl = time.perf_counter()
        n_fix = 0
        if self.enable_reflection:
            for i in range(MAX_REFLECTION_ROUNDS):
                result = self._reflect(query, draft)
                has_issue = result.get("has_issue") and result.get("issues")
                source = result.get("_source", "llm")

                if not has_issue:
                    emit(
                        "🪞",
                        "自检反思",
                        (time.perf_counter() - t_refl) * 1000,
                        f"{i} 次修正  ·  通过  [{source}]",
                    )
                    break

                issues_text = "\n".join(
                    f"- [{it.get('type')}] {it.get('detail')}"
                    for it in result["issues"]
                )
                try:
                    resp = chat(
                        [
                            {
                                "role": "user",
                                "content": FIX_PROMPT.format(
                                    draft=draft, issues_text=issues_text
                                ),
                            }
                        ],
                        model=LLM_MODEL,
                        temperature=0.1,
                    )
                    fix_text = str(resp.get("content", "")).strip()
                    if fix_text:
                        draft = draft + f"\n\n### 补充说明（根据自检）\n{fix_text}"
                        n_fix += 1
                    else:
                        break
                except Exception:
                    break
            else:
                emit(
                    "🪞",
                    "自检反思",
                    (time.perf_counter() - t_refl) * 1000,
                    f"{n_fix} 次修正  ·  达上限",
                )

        self.history.append({"role": "user", "content": query})
        self.history.append({"role": "assistant", "content": draft})

        elapsed = (time.perf_counter() - t_run) * 1000
        hr()
        emit("⏱️", "总耗时", elapsed, f"RAG 缓存 {len(self._rag_cache)} 条")
        hr()
        return draft, elapsed


# ============================================================
#  批量测试
# ============================================================
def run_batch_test(agent: "V3AgentRAG", input_file: str, output_file: str = None):
    if not os.path.exists(input_file):
        print(f"❌ 输入文件不存在：{input_file}")
        sys.exit(1)

    with open(input_file, encoding="utf-8") as f:
        questions = [
            line.strip()
            for line in f
            if line.strip() and not line.strip().startswith("#")
        ]

    if not questions:
        print(f"❌ 输入文件无有效问题：{input_file}")
        sys.exit(1)

    if not output_file:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"test_output_{ts}.txt"

    f_out = open(output_file, "w", encoding="utf-8")
    tee = Tee(sys.__stdout__, f_out)
    old_stdout = sys.stdout
    sys.stdout = tee

    try:
        print("=" * 64)
        print(f"  V3 Agent-RAG 自动测试报告")
        print(f"  测试时间 : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  输入文件 : {input_file}  ({len(questions)} 个问题)")
        print(f"  输出文件 : {output_file}")
        print("=" * 64)
        print()
        print("说明：本报告包含 V3 智能体的完整 ReAct 推理链和最终回答，")
        print("      用于评估 RAG 检索、工具调用、幻觉抑制等能力。")
        print("      工具说明：🔎[真实]=走向量检索，🎭[模拟]=返回硬编码数据。")
        print()

        print("─" * 64)
        print(f"  📋 问题清单（共 {len(questions)} 题）")
        print("─" * 64)
        for idx, q in enumerate(questions, 1):
            display = q if _display_width(q) <= 50 else q[:25] + "..."
            print(f"  {idx:>2}. {display}")
        print("─" * 64)
        print()

        results = []

        for i, q in enumerate(questions, 1):
            print()
            print()
            box_top(64, f"第 {i} / {len(questions)} 题")
            box_line(f"输入问题：{q}")
            box_bottom()

            status = "✅ 完成"
            elapsed = 0
            try:
                ret = agent.run(q, verbose=True)
                if isinstance(ret, tuple):
                    ans, elapsed = ret
                else:
                    ans = ret
                print(f"\n🤖 V3：")
                print(ans)
            except KeyboardInterrupt:
                print(f"\n⚠️  用户中断，跳过剩余测试")
                status = "⏸️ 中断"
                results.append((i, q, elapsed, status))
                break
            except Exception as e:
                import traceback

                print(f"\n❌ 测试 {i} 异常：{type(e).__name__}: {e}")
                print(traceback.format_exc())
                status = f"❌ 异常：{type(e).__name__}"

            results.append((i, q, elapsed, status))

            print()
            print(f"  ─── 第 {i} 题回答完毕 ───")

            # 题间延迟，避免商汤 429
            if i < len(questions):
                time.sleep(1.5)

        print()
        print()
        print("=" * 64)
        print(f"  📊 测试汇总")
        print("=" * 64)
        print(f"  {'#':>2}  {'耗时':>8}  {'状态':<20}  问题")
        print("  " + "─" * 60)
        for idx, q, elapsed, status in results:
            display = q if _display_width(q) <= 30 else q[:15] + "..."
            print(f"  {idx:>2}  {_fmt_ms(elapsed):>8}  {status:<20}  {display}")
        print("  " + "─" * 60)

        ok_count = sum(1 for _, _, _, s in results if "✅" in s)
        print(f"  完成 {ok_count}/{len(results)} 题")
        total_time = sum(e for _, _, e, _ in results)
        print(f"  总耗时：{_fmt_ms(total_time)}")

        print()
        print("=" * 64)
        print(f"  ✅ 自动测试完成")
        print(f"  结果已保存到：{output_file}")
        print("=" * 64)

    finally:
        sys.stdout = old_stdout
        f_out.close()

    print(f"\n✅ 测试完成，结果已保存到：{output_file}")
    print(f"   提示：可将该 txt 文件传给大模型分析，或直接用于实验报告。")


# ============================================================
#  CLI
# ============================================================
def _interactive_mode(agent: "V3AgentRAG"):
    print("=" * 64)
    print("  V3 Agent-RAG（ReAct 可视化 · rerank 关键词 · 缓存 · 增量反思）")
    print("=" * 64)
    print("  工具说明：")
    print("    🔎 RAG检索知识库 [真实] —— 走 Ollama embedding + Chroma 向量检索")
    print("    🎭 查天气/查景点/查美食/查住宿 [模拟] —— 返回硬编码数据")
    print("=" * 64)
    print("  💡 命令行用法：")
    print("     python3 v3_agent_rag.py                     # 交互模式")
    print("     python3 v3_agent_rag.py --test tests/inputs.txt")
    print("     python3 v3_agent_rag.py -t in.txt -o out.txt")
    print("     python3 v3_agent_rag.py --help              # 查看完整用法")
    print("=" * 64)
    print("  交互模式：输入问题回车；输入 q 退出。")
    print("=" * 64)
    while True:
        try:
            q = input("\n你：").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if q.lower() == "q":
            break
        if not q:
            continue
        ret = agent.run(q, verbose=True)
        ans = ret[0] if isinstance(ret, tuple) else ret
        print(f"\n🤖 V3：")
        print(ans)


EPILOG_TEXT = """
================================================================
  命令行用法说明
================================================================

【模式 1】交互模式（默认）

  python3 v3_agent_rag.py

【模式 2】自动测试模式

  python3 v3_agent_rag.py --test <输入文件> [--output <输出文件>]

示例：
  python3 v3_agent_rag.py
  python3 v3_agent_rag.py --test tests/inputs.txt
  python3 v3_agent_rag.py -t tests/inputs.txt -o result.txt
  python3 v3_agent_rag.py --help

输入文件格式：.txt 纯文本，每行一个问题，# 开头为注释。

================================================================
"""


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog="v3_agent_rag.py",
        description="V3 Agent-RAG：交互模式 / 自动测试模式",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=EPILOG_TEXT,
    )
    parser.add_argument(
        "--test",
        "-t",
        metavar="FILE",
        help="自动测试模式：从 FILE 读取问题（每行一个，# 开头为注释）",
    )
    parser.add_argument(
        "--output",
        "-o",
        metavar="FILE",
        help="自动测试输出文件（默认 test_output_<时间戳>.txt）",
    )
    args = parser.parse_args()

    agent = V3AgentRAG()

    if args.test:
        run_batch_test(agent, args.test, args.output)
    else:
        _interactive_mode(agent)
