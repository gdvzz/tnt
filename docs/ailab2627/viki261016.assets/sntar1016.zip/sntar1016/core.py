# core.py
"""
底层封装：
  - embed / get_collection / retrieve：本地 Ollama (nomic-embed-text) + Chroma
  - chat：商汤 sensenova-6.8-flash-lite 对话 API
不用 LangChain，全部手写。
v5.0:
  - chat 加 429 自动重试（指数退避）
  - max_tokens=4096
"""

import json
import time
import requests
import chromadb
from openai import OpenAI

# ============================================================
#  Ollama（嵌入向量，本地）
# ============================================================
OLLAMA_URL = "http://localhost:11434"
EMBED_MODEL = "nomic-embed-text"

# ============================================================
#  Chroma（向量库，本地）
# ============================================================
CHROMA_DIR = "./chroma_db"
COLLECTION_NAME = "travel_kb"

# ============================================================
#  商汤（对话，联网）
# ============================================================
SENSENOVA_API_KEY = "{your key}"
SENSENOVA_BASE_URL = "https://token.sensenova.cn/v1"
SENSENOVA_MODEL = "sensenova-6.8-flash-lite"

_client_sensenova = OpenAI(
    api_key=SENSENOVA_API_KEY,
    base_url=SENSENOVA_BASE_URL,
)


# ============================================================
#  Embedding（Ollama 本地）
# ============================================================
def embed(text: str, model: str = EMBED_MODEL) -> list:
    """调用 Ollama 生成嵌入向量。"""
    r = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": model, "prompt": text},
        timeout=120,
    )
    r.raise_for_status()
    return r.json()["embedding"]


# ============================================================
#  Chat（商汤 API · 带 429 重试）
# ============================================================
def chat(
    messages: list,
    model: str = SENSENOVA_MODEL,
    tools: list = None,
    temperature: float = 0.1,
    timeout: int = 300,
    max_retries: int = 3,
) -> dict:
    """
    调用商汤 sensenova-6.8-flash-lite 对话接口。
    v5.0: 遇到 429 RateLimitError 时自动重试（指数退避）。
    """
    kwargs = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": 4096,
        "stream": False,
    }

    if tools:
        cleaned_tools = []
        for tool in tools:
            tool_copy = json.loads(json.dumps(tool))
            fn = tool_copy.get("function", {})
            fn.pop("strict", None)
            cleaned_tools.append(tool_copy)
        kwargs["tools"] = cleaned_tools

    last_err = None
    for attempt in range(max_retries):
        try:
            resp = _client_sensenova.chat.completions.create(**kwargs)
            return _parse_response(resp)
        except Exception as e:
            err_str = str(e)
            last_err = e
            # 429 RateLimit：重试
            if "429" in err_str and attempt < max_retries - 1:
                wait = 5 * (2**attempt)  # 5s, 10s, 20s
                print(
                    f"  [商汤 429 限流，等待 {wait}s 后重试（第 {attempt+1}/{max_retries} 次）...]",
                    flush=True,
                )
                time.sleep(wait)
                continue
            # 其他错误直接抛
            raise RuntimeError(f"商汤 API 调用失败：{type(e).__name__}: {e}")

    raise RuntimeError(
        f"商汤 API 调用失败（重试 {max_retries} 次后仍失败）：{type(last_err).__name__}: {last_err}"
    )


def _parse_response(resp) -> dict:
    """把 OpenAI SDK 响应转成项目内部 dict 格式。"""
    msg = resp.choices[0].message
    result = {
        "role": "assistant",
        "content": msg.content or "",
        "tool_calls": [],
    }

    if getattr(msg, "tool_calls", None):
        for tc in msg.tool_calls:
            result["tool_calls"].append(
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
            )

    return result


# ============================================================
#  Chroma（向量库）
# ============================================================
_chroma_client = None


def get_collection():
    """惰性创建 Chroma collection。"""
    global _chroma_client
    if _chroma_client is None:
        _chroma_client = chromadb.PersistentClient(path=CHROMA_DIR)
    return _chroma_client.get_or_create_collection(name=COLLECTION_NAME)


def retrieve(query: str, k: int = 20, city: str = None) -> list:
    """
    检索 Top-K 相关文档。
    k 默认 20（宽召回，交给上层关键词精排）。
    city：可选，按城市元数据过滤（传入拼音，如 'wuxi'）。
    """
    coll = get_collection()
    q_emb = embed(query)

    kwargs = {"query_embeddings": [q_emb], "n_results": k}
    if city:
        kwargs["where"] = {"city": city}

    results = coll.query(**kwargs)

    docs = []
    n = len(results["documents"][0]) if results.get("documents") else 0
    for i in range(n):
        docs.append(
            {
                "content": results["documents"][0][i],
                "metadata": (
                    results["metadatas"][0][i] if results.get("metadatas") else {}
                ),
            }
        )
    return docs
