# test_retrieve.py
from core import retrieve, get_collection

print("=" * 60)
print("1. 查 collection 里的 metadata")
coll = get_collection()
data = coll.get()
print(f"   总记录数：{len(data['ids'])}")
if data["metadatas"]:
    cities = {}
    for m in data["metadatas"]:
        c = m.get("city", "?")
        cities[c] = cities.get(c, 0) + 1
    print(f"   cities 分布：{cities}")
    print(f"   第一条 metadata：{data['metadatas'][0]}")

print("\n" + "=" * 60)
print("2. 检索（不加 city 过滤）")
docs = retrieve("无锡 门票 学生优惠", k=4, city=None)
print(f"   命中：{len(docs)} 条")
for i, d in enumerate(docs, 1):
    print(f"   [{i}] {d['content'][:60]}...")

print("\n" + "=" * 60)
print("3. 检索（city='wuxi' 过滤）")
docs = retrieve("无锡 门票 学生优惠", k=4, city="wuxi")
print(f"   命中：{len(docs)} 条")
for i, d in enumerate(docs, 1):
    print(f"   [{i}] {d['content'][:60]}...")
