# app_chainlit.py
"""
Chainlit Web 界面，Jetson 上运行。
v3.3:
  - 修复："你好"等问候语被拦截 → 只保留 /help 命令
  - 后台线程 + 定时更新：前端实时显示"已耗时 Xs"和进度
  - 默认版本 V3
  - 修复 t.trim 报错（空字符串 content）
  - 去掉 cl.Action，用文本指令 /v1 /v2 /v3
启动：chainlit run app_chainlit.py --host 0.0.0.0 --port 8000
"""

import sys
import os
import time
import asyncio
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import chainlit as cl

# ============================================================
#  版本管理
# ============================================================
VERSIONS = {
    "V1": "V1 固定 RAG（每次无脑检索）",
    "V2": "V2 Tool-RAG（Agent 自主调用）",
    "V3": "V3 Agent-RAG（重排序+追问+自检）",
}

DEFAULT_VERSION = "V3"


def _make_agent(version_key: str):
    """version_key: 'V1' / 'V2' / 'V3'"""
    if version_key == "V1":
        import v1_fixed_rag

        return v1_fixed_rag
    elif version_key == "V2":
        from v2_tool_rag import V2ToolRAGAgent

        return V2ToolRAGAgent()
    else:
        from v3_agent_rag import V3AgentRAG

        return V3AgentRAG()


def _version_label(key: str) -> str:
    return VERSIONS.get(key, key)


def _call_agent_sync(agent, version_key: str, query: str) -> str:
    """同步调用 agent（在线程池里运行），确保返回字符串。"""
    try:
        if version_key == "V1":
            result = agent.ask(query)
        else:
            result = agent.run(query)

        # V3.run() 返回 (draft, elapsed) tuple
        if isinstance(result, tuple):
            result = result[0]

        if result is None:
            return "⚠️ 模型未返回内容，请重试。"
        return str(result)

    except Exception as e:
        tb = traceback.format_exc()
        return f"⚠️ 出错：{type(e).__name__}: {e}\n\n```\n{tb}\n```"


def _progress_text(version_key: str, elapsed: float, stage: str = "") -> str:
    """生成进度消息。"""
    label = _version_label(version_key)
    lines = [
        f"⏳ **{label}** 正在处理...",
        "",
        f"**已耗时**：{elapsed:.0f} 秒",
    ]
    if stage:
        lines.append(f"**当前阶段**：{stage}")
    lines.append("")
    lines.append("> 后台正在：检索知识库 → 调用工具 → 生成回答 → 自检")
    return "\n".join(lines)


# ============================================================
#  会话启动
# ============================================================
@cl.on_chat_start
async def on_chat_start():
    cl.user_session.set("version", DEFAULT_VERSION)
    cl.user_session.set("agent", _make_agent(DEFAULT_VERSION))

    welcome = f"""🧳 **旅游智能体已就绪**（当前版本：{_version_label(DEFAULT_VERSION)}）

**运行平台**：NVIDIA Jetson Orin NX 16GB / JetPack 5.1.3
**知识库覆盖**：无锡、厦门、杭州、西安

---

### 🔄 切换版本

在输入框输入指令：

- `/v1` → **V1 固定 RAG**（每次无脑检索）
- `/v2` → **V2 Tool-RAG**（Agent 自主调用，模型名尚未同步商汤，可能报错）
- `/v3` → **V3 Agent-RAG**（重排序+追问+自检）★ 当前默认

---

### 💬 试试这样问

| 类型 | 问题 |
|---|---|
| 完整规划 | `学生党无锡 2 日游，预算 800` |
| 事实查询 | `无锡灵山大佛学生票多少？` |
| 宽召回 | `拈花湾门票多少？几点关门？` |
| 跨城市 | `鼓浪屿船票怎么抢？` |
| 缺城市追问 | `帮我规划 3 天行程` |
| 知识库外 | `无锡到上海高铁多久？` |

---

### 📖 帮助

输入 `/help` 或 `帮助` 查看当前版本和推荐问题。

---

⏱️ 提示：响应约 **15-40 秒**，页面会实时显示已耗时。"""

    await cl.Message(content=welcome).send()


# ============================================================
#  消息处理
# ============================================================
@cl.on_message
async def on_message(message: cl.Message):
    agent = cl.user_session.get("agent")
    version_key = cl.user_session.get("version", DEFAULT_VERSION)

    raw = message.content
    query = (raw or "").strip() if isinstance(raw, str) else ""

    if not query:
        return

    # ---------- 1. 文本指令切换版本 ----------
    if query.lower() in ("/v1", "/v2", "/v3"):
        key = query[1:].upper()
        try:
            cl.user_session.set("version", key)
            cl.user_session.set("agent", _make_agent(key))
            await cl.Message(
                content=f"✅ 已切换到 **{_version_label(key)}**\n\n直接输入问题即可。"
            ).send()
        except Exception as e:
            await cl.Message(content=f"⚠️ 切换版本失败：{type(e).__name__}: {e}").send()
        return

    # ---------- 2. 帮助（只响应 /help 或 帮助） ----------
    # 注意：不拦截"你好"等问候语，交给 agent 处理
    if query in ("/help", "帮助"):
        await cl.Message(content=f"""当前版本：**{_version_label(version_key)}**

**切换版本**：输入 `/v1` `/v2` `/v3`

**推荐问题**：
- 学生党无锡 2 日游，预算 800
- 无锡灵山大佛学生票多少？
- 帮我规划 3 天行程
- 鼓浪屿船票怎么买？""").send()
        return

    # ---------- 3. 正常处理（后台线程 + 定时更新） ----------
    start_time = time.time()

    # 用非空 content 初始化消息（避免 Chainlit 2.x 的 .trim() 报错）
    msg = cl.Message(content=_progress_text(version_key, 0))
    await msg.send()

    # 停止信号
    stop_event = asyncio.Event()

    # 定时更新任务
    async def ticker():
        stage_cycle = [
            "检索知识库",
            "分析用户意图",
            "调用工具",
            "生成回答",
            "自检反思",
        ]
        i = 0
        while not stop_event.is_set():
            try:
                # 每 3 秒更新一次；被 stop_event 唤醒则退出
                await asyncio.wait_for(stop_event.wait(), timeout=3.0)
                break
            except asyncio.TimeoutError:
                elapsed = time.time() - start_time
                stage = stage_cycle[i % len(stage_cycle)]
                i += 1
                try:
                    msg.content = _progress_text(version_key, elapsed, stage)
                    await msg.update()
                except Exception:
                    pass  # update 失败静默继续

    ticker_task = asyncio.create_task(ticker())

    # 在线程池里跑 agent（不阻塞事件循环）
    try:
        answer = await asyncio.to_thread(_call_agent_sync, agent, version_key, query)
    except Exception as e:
        answer = f"⚠️ 处理出错：{type(e).__name__}: {e}"
    finally:
        # 停止 ticker
        stop_event.set()
        try:
            await asyncio.wait_for(ticker_task, timeout=1.0)
        except Exception:
            pass

    # 记录总耗时
    total = time.time() - start_time

    # 更新为最终回答（附加耗时）
    final_content = f"{answer}\n\n---\n⏱️ *总耗时 {total:.1f} 秒*"
    msg.content = final_content
    try:
        await msg.update()
    except Exception:
        await cl.Message(
            content=f"（消息更新失败，以下是回答）\n\n{final_content}"
        ).send()
