# app_chainlit.py
"""
Chainlit Web 界面，Jetson 上运行。
版本切换用 Action 按钮（Chainlit 2.x 兼容）。
启动：chainlit run app_chainlit.py --host 0.0.0.0 --port 8000
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import chainlit as cl


def _make_agent(version_key: str):
    """version_key: 'V1' / 'V2' / 'V3'"""
    if version_key == "V1":
        import v1_fixed_rag
        return v1_fixed_rag
    elif version_key == "V2":
        from v2_tool_rag import V2ToolRAGAgent
        return V2ToolRAGAgent()
    else:
        from v3_agent_rag import V3AgentRAG
        return V3AgentRAG()


def _version_label(key: str) -> str:
    return {
        "V1": "V1 固定 RAG（每次无脑检索）",
        "V2": "V2 Tool-RAG（Agent 自主调用）",
        "V3": "V3 Agent-RAG（重排序+追问+自检）",
    }.get(key, key)


async def _show_version_picker():
    """显示三个版本切换按钮"""
    actions = [
        cl.Action(name="switch_v1", value="V1", label="V1 固定 RAG", description="每次无脑检索"),
        cl.Action(name="switch_v2", value="V2", label="V2 Tool-RAG", description="Agent 自主调用"),
        cl.Action(name="switch_v3", value="V3", label="V3 Agent-RAG", description="重排序+追问+自检"),
    ]
    await cl.Message(
        content="**请选择要运行的版本**（点击下方按钮切换）：",
        actions=actions,
    ).send()


@cl.on_chat_start
async def on_chat_start():
    # 默认 V2
    cl.user_session.set("version", "V2")
    cl.user_session.set("agent", _make_agent("V2"))

    await cl.Message(
        content=f"""🧳 **旅游智能体已就绪**（当前版本：{_version_label('V2')}）

运行平台：**NVIDIA Jetson Orin NX 16GB / JetPack 5.1.3**

知识库覆盖：**无锡、厦门、杭州、西安**

试试这样问：
- 学生党无锡 2 日游，预算 800
- 鼓浪屿船票怎么抢？学生票多少钱？
- 灵隐寺飞来峰学生票多少？
- 陕西历史博物馆怎么约？

⏱️ 提示：Jetson 上 3B 模型响应约 30-50 秒，请耐心等待。"""
    ).send()

    await _show_version_picker()


# ---------- 三个版本切换回调 ----------
@cl.action_callback("switch_v1")
async def on_switch_v1(action: cl.Action):
    cl.user_session.set("version", "V1")
    cl.user_session.set("agent", _make_agent("V1"))
    await cl.Message(content=f"✅ 已切换到 **{_version_label('V1')}**").send()


@cl.action_callback("switch_v2")
async def on_switch_v2(action: cl.Action):
    cl.user_session.set("version", "V2")
    cl.user_session.set("agent", _make_agent("V2"))
    await cl.Message(content=f"✅ 已切换到 **{_version_label('V2')}**").send()


@cl.action_callback("switch_v3")
async def on_switch_v3(action: cl.Action):
    cl.user_session.set("version", "V3")
    cl.user_session.set("agent", _make_agent("V3"))
    await cl.Message(content=f"✅ 已切换到 **{_version_label('V3')}**").send()


# ---------- 处理用户消息 ----------
@cl.on_message
async def on_message(message: cl.Message):
    agent = cl.user_session.get("agent")
    version_key = cl.user_session.get("version", "V2")
    query = message.content.strip()

    # 支持 /v1 /v2 /v3 文本切换
    if query.lower() in ("/v1", "/v2", "/v3"):
        key = query[1:].upper()
        cl.user_session.set("version", key)
        cl.user_session.set("agent", _make_agent(key))
        await cl.Message(content=f"✅ 已切换到 **{_version_label(key)}**").send()
        return

    # 欢迎语
    if query in ("你好", "hi", "hello", "帮助", "/help"):
        await cl.Message(
            content=f"""当前版本：**{_version_label(version_key)}**

切换版本：点击上方按钮，或输入 `/v1` `/v2` `/v3`

推荐问题：
- 学生党无锡 2 日游，预算 800
- 无锡灵山大佛学生票多少？
- 帮我规划 3 天行程"""
        ).send()
        return

    # 正常处理
    msg = cl.Message(content="")
    await msg.send()
    msg.content = f"⏳ **{_version_label(version_key)}** 正在处理，请稍候（约 30-50 秒）..."
    await msg.update()

    try:
        if version_key == "V1":
            answer = agent.ask(query)
        elif version_key == "V2":
            answer = agent.run(query)
        else:
            answer = agent.run(query)
    except Exception as e:
        import traceback
        answer = f"⚠️ 出错：{type(e).__name__}: {e}\n\n```\n{traceback.format_exc()}\n```"

    msg.content = answer
    await msg.update()
