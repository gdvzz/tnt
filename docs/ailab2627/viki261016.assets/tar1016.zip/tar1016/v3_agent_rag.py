# v3_agent_rag.py
"""
V3 Agent-RAG  v3.8
优化：
  1. Rerank 改关键词匹配（无 LLM 调用）
  2. RAG 会话级缓存
  3. Reflection 增量修正
  4. RAG 强制按 city 过滤
  5. SYSTEM_PROMPT 明确按天分节
  6. core.py num_predict 降到 512（加快响应）
"""
import json
import re
import time
from core import retrieve, chat
from tools import TOOLS_SCHEMA, execute_tool, TOOL_REGISTRY, CITY_PINYIN

LLM_MODEL = "qwen2.5:3b"
MAX_HISTORY = 6
MAX_TOOL_ROUNDS = 5
MAX_REFLECTION_ROUNDS = 3

KNOWN_CITIES = ["无锡", "厦门", "杭州", "西安"]


# ============================================================
#  输出工具
# ============================================================
def _fmt_ms(ms: float) -> str:
    return f"{ms/1000:.2f}s" if ms >= 1000 else f"{ms:.0f}ms"


def emit(icon: str, name: str, ms: float, note: str = "", level: int = 0):
    indent = "  " * level
    line = f"{indent}{icon} {name:<22} {_fmt_ms(ms):>8}"
    if note:
        line += f"   {note}"
    print(line, flush=True)


def hr(width: int = 64):
    print("─" * width, flush=True)


# ============================================================
#  Prompt
# ============================================================
SYSTEM_PROMPT = """你是一个专业的学生旅游规划智能体。

【硬约束】
- 景点名称、门票价格、开放时间、预约方式，**必须严格来自用户消息中提供的【知识库真实信息】**。
- **绝对禁止编造景点名**。不确定存在的景点不要写。
- **只能规划用户指定城市的景点**，不要提其他城市。

工具使用规则：
1. 涉及景点门票、预约、学生优惠、开放时间时，必须调用 search_travel_knowledge。
2. **调用 search_travel_knowledge 时必须传入 city 参数**（如 city='无锡'）。
3. 规划行程前，先调用 get_top_attractions 拿景点清单。
4. 天气、美食、住宿按需调用。
5. 最多 5 轮工具调用。

**输出格式（必须严格遵守，按天分节）**：

### 第一天
- 【路线】具体景点顺序 + 交通方式
- 【用餐】早/午/晚推荐
- 【住宿】区域建议
- 【学生提示 & 避坑】学生优惠、预约提醒、注意事项

### 第二天
- 【路线】...
- 【用餐】...
- 【住宿】...
- 【学生提示 & 避坑】...

（以此类推，共 N 天）

**规则**：
- 每天 4 项必须齐全（路线/用餐/住宿/学生提示）
- 必须是具体的景点名，不要笼统描述
- 同一信息只说一次，不要重复
- 回答简洁，不要客套话
"""

SLOT_PROMPT = """从用户查询中提取以下槽位，只输出 JSON：
{{"city": "城市名或 null", "days": 天数或 null, "budget": "预算或 null"}}

用户查询：{query}
只输出 JSON。"""

REFLECTION_PROMPT = """检查以下行程是否存在**明确的具体问题**。严格输出 JSON。

用户需求：{user_query}
行程草案：
{draft}

只检查以下 3 类硬性问题：
1. 景点不存在或明显编造
2. 同一天景点跨城
3. 关键信息缺失（如没提学生票或预约）

符合则输出 {{"has_issue": false, "issues": []}}
否则输出 {{"has_issue": true, "issues": [{{"type": "类型", "detail": "描述"}}]}}

只输出 JSON。"""

FIX_PROMPT = """根据审核意见，**只输出需要补充的条目**（不重写整个行程）。

【当前行程】
{draft}

【审核意见】
{issues_text}

【要求】
- 每条以 "- " 开头，简洁
- 最多 5 条
- 不要重复行程中已有的内容
- 只输出条目，不要其他解释
"""


# ============================================================
#  Rerank：关键词匹配
# ============================================================
def _keyword_rerank(query: str, docs: list, top_k: int = 3) -> list:
    """关键词命中数重排，O(n)，毫秒级"""
    keywords = set(re.findall(r'[\u4e00-\u9fa5]{2,}|[a-zA-Z]+', query))
    if not keywords:
        return docs[:top_k]
    scored = []
    for i, d in enumerate(docs):
        content = d.get("content", "")
        hits = sum(1 for kw in keywords if kw in content)
        scored.append((i, hits))
    scored.sort(key=lambda x: (-x[1], x[0]))
    return [docs[i] for i, _ in scored[:top_k]]


def rag_retrieve(query: str, city: str = None) -> dict:
    """向量检索（按 city 过滤）+ 关键词重排"""
    city_pinyin = CITY_PINYIN.get(city) if city else None
    docs = retrieve(query, k=4, city=city_pinyin)
    if not docs:
        return {"rag_query": query, "city": city, "retrieved": [], "note": "未找到"}
    top_docs = _keyword_rerank(query, docs, top_k=3)
    return {
        "rag_query": query,
        "city": city,
        "retrieved": [d["content"] for d in top_docs],
    }


# ============================================================
#  Agent
# ============================================================
class V3AgentRAG:
    def __init__(self, enable_reflection: bool = True, enable_ask: bool = True):
        self.history = []
        self.context = {"city": None, "days": None, "budget": None}
        self.enable_reflection = enable_reflection
        self.enable_ask = enable_ask

        self._rag_cache = {}

        TOOL_REGISTRY["search_travel_knowledge"] = (
            lambda q, city=None: self._cached_rag(q, city=city)
        )

    def _cached_rag(self, query: str, city: str = None) -> dict:
        key = f"{city or ''}|{query.strip()}"
        if key in self._rag_cache:
            return self._rag_cache[key]
        result = rag_retrieve(query, city=city)
        self._rag_cache[key] = result
        return result

    def _extract_slots(self, query: str) -> dict:
        t0 = time.perf_counter()

        detected_city = None
        for city in KNOWN_CITIES:
            if city in query:
                detected_city = city
                break

        days, budget = None, None
        try:
            resp = chat(
                [{"role": "user", "content": SLOT_PROMPT.format(query=query)}],
                model=LLM_MODEL, temperature=0.0,
            )
            raw = str(resp.get("content", "")).strip()

            m = re.search(r'"days"\s*:\s*"?(\d+)"?', raw)
            if m:
                days = int(m.group(1))

            m = re.search(r'"budget"\s*:\s*"?([^",}\s]+)"?', raw)
            if m and m.group(1).lower() not in ("null", "none"):
                budget = m.group(1)

            if not detected_city:
                m = re.search(r'"city"\s*:\s*"([^"]+)"', raw)
                if m and m.group(1).lower() not in ("null", "none"):
                    for c in KNOWN_CITIES:
                        if c in m.group(1):
                            detected_city = c
                            break
        except Exception as ex:
            print(f"  ⚠️  slots 解析异常：{type(ex).__name__}: {ex}")

        emit("📝", "槽位提取", (time.perf_counter() - t0) * 1000,
             f"city={detected_city}  days={days}  budget={budget}")
        return {"city": detected_city, "days": days, "budget": budget}

    def _should_ask_city(self, query: str) -> bool:
        if not self.enable_ask:
            return False
        planning_kw = ["规划", "行程", "安排", "路线", "日游", "旅游", "玩"]
        if not any(k in query for k in planning_kw):
            return False
        return self.context["city"] is None

    def _truncate(self):
        if len(self.history) > MAX_HISTORY * 2:
            self.history = self.history[-MAX_HISTORY * 2:]

    def _react(self, query: str, city: str = None, extra_context: str = None) -> str:
        t_start = time.perf_counter()

        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(self.history)

        if extra_context:
            user_content = f"""【知识库真实信息 —— 必须严格使用，不得编造景点名称】
{extra_context}

【用户需求】
{query}"""
        else:
            user_content = query
        messages.append({"role": "user", "content": user_content})

        n_llm = 0
        n_tool = 0

        for rnd in range(MAX_TOOL_ROUNDS):
            try:
                resp = chat(messages, model=LLM_MODEL, tools=TOOLS_SCHEMA, temperature=0.1)
                n_llm += 1
            except Exception as e:
                emit("🤖", "ReAct 循环", (time.perf_counter() - t_start) * 1000,
                     f"LLM 异常：{e}")
                return f"⚠️ 模型调用失败：{e}"

            tool_calls = resp.get("tool_calls") or []
            if not tool_calls:
                emit("🤖", "ReAct 循环", (time.perf_counter() - t_start) * 1000,
                     f"{n_llm} 轮 LLM  ·  {n_tool} 次工具")
                return resp.get("content", "")

            messages.append(resp)
            for tc in tool_calls:
                fn_info = tc.get("function", {})
                name = fn_info.get("name")
                args = fn_info.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}

                if name == "search_travel_knowledge" and city and not args.get("city"):
                    args["city"] = city

                t0 = time.perf_counter()
                result = execute_tool(name, args)
                t_tool = (time.perf_counter() - t0) * 1000
                n_tool += 1
                city_note = f"  city={args.get('city')}" if name == "search_travel_knowledge" else ""
                print(f"     ├─ {name:<28} {_fmt_ms(t_tool):>8}{city_note}", flush=True)
                messages.append({"role": "tool", "content": result})

        try:
            resp = chat(messages, model=LLM_MODEL, temperature=0.1)
            emit("🤖", "ReAct 循环", (time.perf_counter() - t_start) * 1000,
                 f"{n_llm} 轮 LLM  ·  {n_tool} 次工具  ⚠️ 达上限")
            return resp.get("content", "")
        except Exception as e:
            emit("🤖", "ReAct 循环", (time.perf_counter() - t_start) * 1000,
                 f"达上限且生成失败")
            return f"⚠️ 达到最大轮次：{e}"

    def _reflect(self, query: str, draft: str) -> dict:
        try:
            resp = chat(
                [{"role": "user", "content": REFLECTION_PROMPT.format(user_query=query, draft=draft)}],
                model=LLM_MODEL, temperature=0.0,
            )
            text = str(resp.get("content", "")).strip()

            s, e = text.find("{"), text.rfind("}")
            if s != -1 and e != -1:
                try:
                    data = json.loads(text[s:e + 1])
                    if isinstance(data, dict) and "has_issue" in data:
                        return data
                except json.JSONDecodeError:
                    pass

            if re.search(r'"has_issue"\s*:\s*true', text):
                return {"has_issue": True, "issues": [{"type": "一般问题", "detail": "见草案"}]}
        except Exception as ex:
            print(f"  ⚠️  reflect 异常：{type(ex).__name__}: {ex}")
        return {"has_issue": False, "issues": []}

    def run(self, query: str, verbose: bool = False) -> str:
        t_run = time.perf_counter()
        self._truncate()

        print()
        hr()
        print(f"🎫 你：{query}")
        hr()

        # 1. slots
        slots = self._extract_slots(query)
        if slots.get("city"):
            self.context["city"] = slots["city"]
        if slots.get("days"):
            self.context["days"] = slots["days"]
        if slots.get("budget"):
            self.context["budget"] = slots["budget"]

        # 2. 追问
        if self._should_ask_city(query):
            emit("❓", "追问城市", (time.perf_counter() - t_run) * 1000)
            hr()
            return "请问您想去哪个城市呢？（目前知识库覆盖：无锡、厦门、杭州、西安）"

        # 3. 前置检索
        t_pre = time.perf_counter()
        planning_kw = ["规划", "行程", "安排", "路线", "日游", "旅游", "玩"]
        is_planning = any(k in query for k in planning_kw)
        extra_context = None

        if is_planning and self.context["city"]:
            city = self.context["city"]

            attr_result = execute_tool("get_top_attractions", {"city": city})

            prefetch_query = f"{city} 门票 预约 学生优惠 开放时间 避坑"
            rag_result = self._cached_rag(prefetch_query, city=city)
            retrieved = rag_result.get("retrieved", [])

            extra_context = (f"【{city}热门景点列表】\n{attr_result}\n\n"
                             f"【{city}详细知识】\n" + "\n\n".join(retrieved))
            emit("🔍", "前置检索", (time.perf_counter() - t_pre) * 1000,
                 f"city={city}  景点清单 + {len(retrieved)} 条知识")

        # 4. ReAct
        draft = self._react(query, city=self.context["city"], extra_context=extra_context)

        # 5. Reflection（增量修正）
        t_refl = time.perf_counter()
        n_fix = 0
        if self.enable_reflection:
            for i in range(MAX_REFLECTION_ROUNDS):
                result = self._reflect(query, draft)
                has_issue = result.get("has_issue") and result.get("issues")

                if not has_issue:
                    emit("🪞", "自检反思", (time.perf_counter() - t_refl) * 1000,
                         f"{i} 次修正  ·  通过")
                    break

                issues_text = "\n".join(
                    f"- [{it.get('type')}] {it.get('detail')}" for it in result["issues"]
                )
                try:
                    resp = chat(
                        [{"role": "user", "content": FIX_PROMPT.format(draft=draft, issues_text=issues_text)}],
                        model=LLM_MODEL, temperature=0.1,
                    )
                    fix_text = str(resp.get("content", "")).strip()
                    draft = draft + f"\n\n### 补充说明（根据自检）\n{fix_text}"
                    n_fix += 1
                except Exception:
                    break
            else:
                emit("🪞", "自检反思", (time.perf_counter() - t_refl) * 1000,
                     f"{n_fix} 次修正  ·  达上限")

        # 6. 收尾
        self.history.append({"role": "user", "content": query})
        self.history.append({"role": "assistant", "content": draft})

        hr()
        emit("⏱️", "总耗时", (time.perf_counter() - t_run) * 1000,
             f"RAG 缓存 {len(self._rag_cache)} 条")
        hr()
        return draft


# ============================================================
#  CLI
# ============================================================
if __name__ == "__main__":
    agent = V3AgentRAG()
    print("=" * 64)
    print("  V3 Agent-RAG（rerank 关键词 · 缓存 · 增量反思 · city 过滤）")
    print("=" * 64)
    while True:
        q = input("\n你：").strip()
        if q.lower() == "q":
            break
        if not q:
            continue
        ans = agent.run(q, verbose=True)
        print(f"\n🤖 V3：{ans}")
