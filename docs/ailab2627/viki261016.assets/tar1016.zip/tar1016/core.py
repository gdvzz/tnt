# core.py
"""
Jetson 原生封装：Ollama /api/embeddings + /api/chat + Chroma。
不用 LangChain，全部手写。
v3.8: num_predict 从 1024 降到 512，加快响应。
"""
import json
import requests
import chromadb

OLLAMA_URL = "http://localhost:11434"
CHROMA_DIR = "./chroma_db"
COLLECTION_NAME = "travel_kb"


def embed(text: str, model: str = "nomic-embed-text") -> list:
    """调用 Ollama 生成嵌入向量。"""
    r = requests.post(
        f"{OLLAMA_URL}/api/embeddings",
        json={"model": model, "prompt": text},
        timeout=120,
    )
    r.raise_for_status()
    return r.json()["embedding"]


def chat(messages: list, model: str = "qwen2.5:3b",
         tools: list = None, temperature: float = 0.1,
         timeout: int = 300) -> dict:
    """调用 Ollama 对话接口（含 function calling）。"""
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "temperature": temperature,
        "options": {"num_predict": 512},
    }
    if tools:
        payload["tools"] = tools
    r = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=timeout)
    r.raise_for_status()
    return r.json()["message"]


_client = None


def get_collection():
    """惰性创建 Chroma collection。"""
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(path=CHROMA_DIR)
    return _client.get_or_create_collection(name=COLLECTION_NAME)


def retrieve(query: str, k: int = 3, city: str = None) -> list:
    """
    检索 Top-K 相关文档。
    city：可选，按城市元数据过滤（传入拼音，如 'wuxi'）。
    """
    coll = get_collection()
    q_emb = embed(query)

    kwargs = {"query_embeddings": [q_emb], "n_results": k}
    if city:
        kwargs["where"] = {"city": city}

    results = coll.query(**kwargs)

    docs = []
    n = len(results["documents"][0]) if results["documents"] else 0
    for i in range(n):
        docs.append({
            "content": results["documents"][0][i],
            "metadata": results["metadatas"][0][i] if results.get("metadatas") else {},
        })
    return docs
