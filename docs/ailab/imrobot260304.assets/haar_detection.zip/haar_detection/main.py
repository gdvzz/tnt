import time
import cv2 as cv
import numpy as np
import os # 导入os模块以检查文件是否存在

class FaceEyeDetection:
    def __init__(self):
        # 定义模型文件的路径
        face_cascade_path = "haarcascade_frontalface_default.xml"
        eye_cascade_path = "haarcascade_eye.xml"

        # --- 关键改动：检查并从本地加载模型文件 ---
        if not os.path.exists(face_cascade_path) or not os.path.exists(eye_cascade_path):
            print("错误：模型文件 (.xml) 未找到！")
            print(f"请确保 '{face_cascade_path}' 和 '{eye_cascade_path}' 与脚本在同一个目录下。")
            exit()
            
        self.faceDetect = cv.CascadeClassifier(face_cascade_path)
        self.eyeDetect = cv.CascadeClassifier(eye_cascade_path)
        # --- 关键改动结束 ---

    def detect_faces(self, frame):
        """检测图像中的人脸并绘制标记"""
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        # detectMultiScale返回一个矩形列表，每个矩形是 (x, y, w, h)
        faces = self.faceDetect.detectMultiScale(gray, 1.3, 5)
        for (x, y, w, h) in faces:
            frame = self.draw_face_bbox(frame, (x, y, w, h))
        return frame

    def detect_eyes(self, frame):
        """检测图像中的眼睛并绘制标记"""
        gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        eyes = self.eyeDetect.detectMultiScale(gray, 1.3, 5)
        for (ex, ey, ew, eh) in eyes:
            center = (int(ex + ew / 2), int(ey + eh / 2))
            radius = int(eh / 2)
            cv.circle(frame, center, radius, (0, 0, 255), 2)
        return frame

    def draw_face_bbox(self, frame, bbox, l=30, t=10):
        """在人脸周围绘制一个带装饰性边框的矩形"""
        x, y, w, h = bbox
        x1, y1 = x + w, y + h
        # 主矩形
        cv.rectangle(frame, (x, y), (x1, y1), (255, 0, 255), 2)
        # 左上角
        cv.line(frame, (x, y), (x + l, y), (255, 0, 255), t)
        cv.line(frame, (x, y), (x, y + l), (255, 0, 255), t)
        # 右上角
        cv.line(frame, (x1, y), (x1 - l, y), (255, 0, 255), t)
        cv.line(frame, (x1, y), (x1, y + l), (255, 0, 255), t)
        # 左下角
        cv.line(frame, (x, y1), (x + l, y1), (255, 0, 255), t)
        cv.line(frame, (x, y1), (x, y1 - l), (255, 0, 255), t)
        # 右下角
        cv.line(frame, (x1, y1), (x1 - l, y1), (255, 0, 255), t)
        cv.line(frame, (x1, y1), (x1, y1 - l), (255, 0, 255), t)
        return frame

if __name__ == '__main__':
    capture = cv.VideoCapture(0)
    capture.set(cv.CAP_PROP_FRAME_WIDTH, 640)
    capture.set(cv.CAP_PROP_FRAME_HEIGHT, 480)
    print("摄像头FPS: ", capture.get(cv.CAP_PROP_FPS))

    pTime, cTime = 0, 0
    
    # 初始化检测器
    face_eye_detector = FaceEyeDetection()
    
    content = ["face", "eye", "face_eye"]
    content_index = 0
    
    while capture.isOpened():
        ret, frame = capture.read()
        if not ret:
            print("读取视频帧失败，退出。")
            break

        frame = cv.flip(frame, 1) # 添加翻转，使其像镜子一样

        # -- 模式切换逻辑 --
        action = cv.waitKey(1) & 0xFF
        if action == ord('f') or action == ord('F'):
            content_index = (content_index + 1) % len(content)
            print(f"模式切换到: {content[content_index]}")

        # -- 根据模式执行检测 --
        mode = content[content_index]
        if mode == "face":
            frame = face_eye_detector.detect_faces(frame)
        elif mode == "eye":
            frame = face_eye_detector.detect_eyes(frame)
        elif mode == "face_eye":
            # 先检测人脸，再检测眼睛，可以稍微提高眼睛检测的准确性
            frame = face_eye_detector.detect_faces(frame)
            frame = face_eye_detector.detect_eyes(frame)

        if action == ord('q') or action == ord('Q'):
            break

        # -- 计算并显示FPS --
        cTime = time.time()
        fps = 1 / (cTime - pTime) if (cTime - pTime) > 0 else 0
        pTime = cTime
        text = f"FPS: {int(fps)} Mode: {mode}"
        cv.putText(frame, text, (20, 30), cv.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        
        cv.imshow('Face and Eye Detection', frame)
        
    capture.release()
    cv.destroyAllWindows()