# 一、实验介绍

## 1. 实验内容

本实验将使用 RAG（Retrieval-Augmented Generation，检索增强生成）系统构建一个专门针对 PDF 文档的智能问答系统。与通用 RAG 系统不同，本实验专注于 PDF 文档的处理，并提供了基于 Gradio 的 Web 界面，让用户可以通过友好的图形界面与 PDF 文档进行交互。本实验将学习如何构建一个完整的 PDF 专用 RAG 系统，包括 PDF 文档加载、向量化存储、相似度检索、答案生成以及 Web 界面开发等核心模块。

## 2. 实验要点

- 了解 RAG 系统的基本原理和工作流程
- 学习 LangChain 框架的使用方法
- 掌握 PDF 文档加载、文本分割、向量化存储等关键技术
- 学会使用 FAISS 进行高效的向量检索
- 理解如何将检索到的上下文信息与大语言模型结合生成答案
- 学习使用 Gradio 构建 Web 界面，提供友好的用户交互体验
- 理解 PDF 专用 RAG 系统与通用 RAG 系统的区别和优势

## 3. 实验环境

- Python 3
- LangChain 框架
- FAISS 向量数据库
- Qwen 大语言模型（通过 API 端点访问）
- Gradio Web 框架

# 二、实验步骤

## 2.1 RAG介绍

RAG（检索增强生成）系统是一种结合了信息检索和生成式 AI 的先进技术。其核心思想是：当用户提出问题时，系统首先从知识库中检索相关的文档片段，然后将这些上下文信息与大语言模型结合，生成更准确、更有依据的答案。相比直接使用大语言模型，RAG 系统能够：

1. **提供事实依据**：答案基于实际文档内容，而非模型训练数据
2. **减少幻觉**：通过检索到的上下文约束，降低模型编造信息的可能性
3. **支持知识更新**：只需更新知识库，无需重新训练模型
4. **提高准确性**：针对特定领域的知识库能够提供更专业的回答

![image-20251113150634411](C:\Users\l1769\AppData\Roaming\Typora\typora-user-images\image-20251113150634411.png)

主要流程：

- 数据入库：读取 PDF 文档并切成小块，并把这些小块经过编码embedding后，存储在一个向量数据库中；
- 相关性检索：用户提出问题，问题经过编码，再在向量数据库中做相似性检索，获取与问题相关的信息块context，并通过重排序算法，输出最相关的N个context；
- 问题输出：相关段落context + 问题组合形成prompt输入大模型中，大模型输出一个答案或采取一个行动

本实验使用的 RAG 系统基于 LangChain 框架构建，采用模块化设计，代码结构清晰，便于理解和扩展。与通用 RAG 系统相比，本系统专门针对 PDF 文档进行了优化，并提供了 Web 界面支持。

## 2.2 项目结构介绍

本项目的代码采用模块化设计，主要包含以下目录和文件：

```
chatpdf/
├── config/              # 配置模块
│   ├── __init__.py
│   └── settings.py      # 配置文件
├── models/              # 模型封装
│   ├── __init__.py
│   ├── llm.py          # LLM 模型封装
│   └── embedding.py    # 嵌入模型封装
├── chains/              # RAG 链
│   ├── __init__.py
│   └── rag_chain.py    # RAG 链实现
├── utils/               # 工具函数
│   ├── __init__.py
│   └── pdf_loader.py    # PDF 文档加载工具（仅支持 PDF）
├── vectorstore/         # 向量存储目录（自动生成）
├── main.py             # 主程序入口（命令行接口）
├── gradio_app.py       # Gradio Web 应用
├── requirements.txt    # 依赖文件
└── handbook.md         # 本实验手册
```


## 2.3 配置模块详解（config/settings.py）

配置模块负责管理整个系统的配置参数，使用 `pydantic-settings` 库实现配置管理。

### 2.3.1 配置类定义

```python
class Settings(BaseSettings):
    """应用配置"""
    
    # LLM 模型配置
    LLM_BASE_URL: str = "https://prodsvc.educg.net/serve-qwen25-32b-instruct/v1"
    LLM_MODEL_NAME: str = "qwen2.5-32b-instruct"
    LLM_API_KEY: str = "EMPTY"
    LLM_TEMPERATURE: float = 0.7
    LLM_MAX_TOKENS: int = 2048
    
    # 嵌入模型配置
    EMBEDDING_BASE_URL: str = "https://prodsvc.educg.net/serve-qwen3-embedding-8b/v1"
    EMBEDDING_MODEL_NAME: str = "qwen3-embedding-8b"
    EMBEDDING_API_KEY: str = "EMPTY"
    EMBEDDING_DIMENSION: int = 1024  # 根据实际模型调整
    
    # 向量存储配置
    VECTOR_STORE_PATH: str = "./vectorstore"
    CHUNK_SIZE: int = 1000
    CHUNK_OVERLAP: int = 200
    
    # 检索配置
    TOP_K: int = 4  # 检索相关文档数量
```

### 2.3.2 配置参数说明

1. **LLM 模型配置**
   - `LLM_BASE_URL`: 大语言模型的 API 端点地址
   - `LLM_MODEL_NAME`: 使用的模型名称
   - `LLM_TEMPERATURE`: 生成温度，控制输出的随机性（0-1，值越大越随机）
   - `LLM_MAX_TOKENS`: 最大生成 token 数，限制答案长度

2. **嵌入模型配置**
   - `EMBEDDING_BASE_URL`: 嵌入模型的 API 端点地址
   - `EMBEDDING_MODEL_NAME`: 嵌入模型名称
   - `EMBEDDING_DIMENSION`: 嵌入向量的维度（1024 维）

3. **向量存储配置**
   - `VECTOR_STORE_PATH`: 向量存储的保存路径
   - `CHUNK_SIZE`: 文档分块大小（1000 字符）
   - `CHUNK_OVERLAP`: 分块之间的重叠大小（200 字符），用于保持上下文连贯性

4. **检索配置**
   - `TOP_K`: 检索时返回的最相关文档数量（4 个）

### 2.3.3 环境变量支持

配置类支持从 `.env` 文件读取配置，方便在不同环境中使用不同的配置：

```python
class Config:
    env_file = ".env"
    env_file_encoding = "utf-8"
```

## 2.4 模型封装模块详解

### 2.4.1 LLM 模型封装（models/llm.py）

LLM 模型封装模块提供了统一的接口来获取大语言模型实例。

#### 核心函数：`get_llm()`

```python
def get_llm(
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
) -> BaseChatModel:
    """
    获取 LLM 模型实例
    
    Args:
        temperature: 生成温度，默认使用配置值
        max_tokens: 最大生成token数，默认使用配置值
    
    Returns:
        LangChain ChatModel 实例
    """
    return ChatOpenAI(
        base_url=settings.LLM_BASE_URL,
        model=settings.LLM_MODEL_NAME,
        temperature=temperature or settings.LLM_TEMPERATURE,
        max_tokens=max_tokens or settings.LLM_MAX_TOKENS,
        api_key=settings.LLM_API_KEY
    )
```

**功能说明**：
- 使用 LangChain 的 `ChatOpenAI` 类，兼容 OpenAI API 格式
- 支持自定义端点的模型服务
- 可以通过参数覆盖默认配置（temperature、max_tokens）
- 返回的模型实例可以用于生成文本、对话等任务

**使用示例**：
```python
from models import get_llm

llm = get_llm()
response = llm.invoke("你好")
```

### 2.4.2 嵌入模型封装（models/embedding.py）

嵌入模型封装模块提供了获取文本嵌入向量的接口。

#### 核心函数：`get_embedding_model()`

```python
def get_embedding_model() -> Embeddings:
    """
    获取嵌入模型实例
    
    Returns:
        LangChain Embeddings 实例
    """
    return OpenAIEmbeddings(
        base_url=settings.EMBEDDING_BASE_URL,
        model=settings.EMBEDDING_MODEL_NAME,
        api_key=settings.EMBEDDING_API_KEY
    )
```

**功能说明**：
- 使用 LangChain 的 `OpenAIEmbeddings` 类
- 将文本转换为高维向量（1024 维）
- 向量可以用于计算文本之间的相似度
- 支持批量嵌入，提高处理效率

**使用示例**：
```python
from models import get_embedding_model

embeddings = get_embedding_model()
vector = embeddings.embed_query("这是要嵌入的文本")
```

**嵌入向量的作用**：
- 将文本转换为数值向量，便于计算机处理
- 语义相似的文本在向量空间中距离更近
- 支持高效的相似度检索

## 2.5 工具函数模块详解（utils/pdf_loader.py）

工具函数模块提供了 PDF 文档加载和文本分割的功能。**注意：本系统仅支持 PDF 格式**。

### 2.5.1 PDF 文档加载函数：`load_pdf()`

```python
def load_pdf(file_path: Union[str, Path]) -> List[Document]:
    """
    加载 PDF 文档
    
    Args:
        file_path: PDF 文件路径
    
    Returns:
        文档列表
    
    Raises:
        FileNotFoundError: 文件不存在
        ValueError: 文件不是 PDF 格式
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    suffix = file_path.suffix.lower()
    if suffix != ".pdf":
        raise ValueError(f"仅支持 PDF 格式文件，当前文件: {file_path}")
    
    # 使用 PyPDFLoader 加载 PDF
    loader = PyPDFLoader(str(file_path))
    documents = loader.load()
    
    return documents
```

**功能说明**：
- 使用 `PyPDFLoader` 加载 PDF 文件
- 自动检查文件格式，如果不是 PDF 会抛出明确的错误
- 返回 LangChain 的 `Document` 对象列表
- 每个 `Document` 包含 `page_content`（文本内容）和 `metadata`（元数据，如页码）

**为什么仅支持 PDF**：
- 专注于 PDF 文档处理，提供更好的错误提示
- 简化代码逻辑，避免多格式支持的复杂性
- PDF 是常见的文档格式，满足大多数使用场景

### 2.5.2 文档分割函数：`split_documents()`

```python
def split_documents(documents: List[Document]) -> List[Document]:
    """
    将文档分割成小块
    
    Args:
        documents: 原始文档列表
    
    Returns:
        分割后的文档列表
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP,
        length_function=len,
    )
    
    split_docs = text_splitter.split_documents(documents)
    return split_docs
```

**功能说明**：
- 使用 `RecursiveCharacterTextSplitter` 进行智能分割
- 按照配置的 `CHUNK_SIZE`（1000 字符）分割文档
- 使用 `CHUNK_OVERLAP`（200 字符）重叠，保持上下文连贯性
- 使用len函数作为字符数计算函数

**为什么需要分割文档**：
1. **向量存储限制**：大文档无法直接存储为单个向量
2. **检索精度**：小块的文档片段能够更精确地匹配用户问题
3. **上下文管理**：只检索相关片段，减少无关信息干扰

## 2.6 RAG 链核心模块详解（chains/rag_chain.py）

RAG 链模块是整个系统的核心，负责协调检索和生成过程。

### 2.6.1 RAGChain 类初始化

```python
class RAGChain:
    def __init__(
        self,
        vector_store_path: Optional[str] = None,
        persist: bool = True,
    ):
        """初始化 RAG 链"""
        self.vector_store_path = vector_store_path or settings.VECTOR_STORE_PATH
        self.persist = persist
        self.llm = get_llm()
        self.embeddings = get_embedding_model()
        self.vector_store: Optional[FAISS] = None
        self.retriever = None
        self.chain = None
        
        # 创建向量存储目录
        Path(self.vector_store_path).mkdir(parents=True, exist_ok=True)
```

**初始化过程**：
1. 设置向量存储路径（默认 `./vectorstore`）
2. 初始化 LLM 和嵌入模型
3. 创建向量存储目录（如果不存在）
4. 初始化向量存储、检索器和链为 `None`（后续构建）

### 2.6.2 构建向量存储：`build_vector_store()`

```python
def build_vector_store(self, documents: List[Document], append: bool = False) -> None:
    """
    构建向量存储
    
    Args:
        documents: 文档列表
        append: 如果为 True 且向量存储已存在，则追加文档；否则覆盖
    """
    if not documents:
        raise ValueError("文档列表不能为空")
    
    # 分割文档
    split_docs = split_documents(documents)
    
    # 检查向量存储是否已存在
    vector_store_file = Path(self.vector_store_path) / "index.faiss"
    
    if append and vector_store_file.exists():
        # 如果启用追加模式且向量存储已存在，则加载并添加文档
        print("检测到已存在的向量存储，正在加载...")
        self.vector_store = FAISS.load_local(
            self.vector_store_path,
            self.embeddings,
            allow_dangerous_deserialization=True,
        )
        print(f"正在添加 {len(split_docs)} 个文档块到现有向量存储...")
        self.vector_store.add_documents(split_docs)
    else:
        # 创建新的向量存储（覆盖已存在的）
        if vector_store_file.exists():
            print("警告: 向量存储已存在，将被覆盖。如需增量添加，请使用 append=True 参数。")
        self.vector_store = FAISS.from_documents(
            documents=split_docs,
            embedding=self.embeddings,
        )
    
    # 持久化
    if self.persist:
        self.vector_store.save_local(self.vector_store_path)
    
    # 创建检索器
    self.retriever = self.vector_store.as_retriever(
        search_kwargs={"k": settings.TOP_K}
    )
    
    # 构建 RAG 链
    self._build_chain()
```

**构建流程**：
1. **文档分割**：将原始文档分割成小块
2. **向量化**：使用嵌入模型将每个文档块转换为向量
3. **存储**：使用 FAISS 创建向量索引并存储
4. **持久化**：保存到磁盘，下次可以直接加载
5. **创建检索器**：配置检索参数（返回 TOP_K 个最相关文档）
6. **构建链**：组装完整的 RAG 处理链

**FAISS 简介**：
- Facebook AI Similarity Search，高效的向量相似度搜索库
- 支持快速检索最相似的向量
- 支持索引持久化，可以保存和加载

### 2.6.3 加载向量存储：`load_vector_store()`

```python
def load_vector_store(self) -> None:
    """
    从磁盘加载向量存储
    """
    vector_store_file = Path(self.vector_store_path) / "index.faiss"
    
    if not vector_store_file.exists():
        raise FileNotFoundError(
            f"向量存储不存在: {self.vector_store_path}。请先调用 build_vector_store() 构建向量存储。"
        )
    
    self.vector_store = FAISS.load_local(
        self.vector_store_path,
        self.embeddings,
        allow_dangerous_deserialization=True,
    )
    
    # 创建检索器
    self.retriever = self.vector_store.as_retriever(
        search_kwargs={"k": settings.TOP_K}
    )
    
    # 构建 RAG 链
    self._build_chain()
```

**加载流程**：
1. 检查向量存储文件是否存在
2. 从磁盘加载 FAISS 索引
3. 重新创建检索器和 RAG 链

**为什么需要加载**：
- 向量存储构建耗时，避免每次都重新构建
- 支持增量更新，可以添加新文档

### 2.6.4 构建 RAG 链：`_build_chain()`

```python
def _build_chain(self) -> None:
    """构建 RAG 链"""
    # 定义提示模板
    template = """基于以下 PDF 文档的上下文信息回答问题。如果上下文中没有相关信息，请说明你不知道，不要编造答案。

上下文信息：
{context}

问题：{question}

请提供准确、有用的答案："""
    
    prompt = ChatPromptTemplate.from_template(template)
    
    # 构建链：检索 -> 格式化 -> LLM -> 输出解析
    self.chain = (
        {
            "context": self.retriever | self._format_docs,
            "question": RunnablePassthrough(),
        }
        | prompt
        | self.llm
        | StrOutputParser()
    )
```

**RAG 链的工作流程**：

1. **输入问题**：用户提出问题
2. **检索相关文档**：`self.retriever` 根据问题向量检索最相关的文档片段
3. **格式化文档**：`self._format_docs` 将多个文档片段合并成字符串
4. **构建提示**：将上下文和问题填入提示模板（注意：提示模板中明确说明是基于 PDF 文档）
5. **生成答案**：LLM 基于上下文和问题生成答案
6. **解析输出**：`StrOutputParser` 将模型输出解析为字符串

**提示模板的作用**：
- 指导模型如何使用检索到的上下文
- 要求模型基于上下文回答，不要编造
- 明确说明是基于 PDF 文档，提高答案的准确性和可靠性

### 2.6.5 格式化文档：`_format_docs()`

```python
@staticmethod
def _format_docs(docs: List[Document]) -> str:
    """
    格式化检索到的文档

    Args:
        docs: 文档列表

    Returns:
        格式化后的字符串
    """
    return "\n\n".join(doc.page_content for doc in docs)
```

**功能**：将多个文档片段用双换行符连接，形成完整的上下文字符串。

### 2.6.6 查询函数：`query()`

```python
def query(self, question: str) -> str:
    """
    查询 RAG 系统

    Args:
        question: 用户问题

    Returns:
        生成的答案
    """
    if self.chain is None:
        raise ValueError(
            "RAG 链未初始化。请先调用 build_vector_store() 或 load_vector_store()。"
        )

    return self.chain.invoke(question)
```

**功能**：执行完整的 RAG 流程，返回答案。

### 2.6.7 添加文档：`add_documents()`

```python
def add_documents(self, documents: List[Document]) -> None:
    """
    向现有向量存储添加文档

    Args:
        documents: 新文档列表
    """
    if self.vector_store is None:
        raise ValueError("向量存储未初始化。请先调用 build_vector_store() 或 load_vector_store()。")

    # 分割文档
    split_docs = split_documents(documents)

    # 添加文档到向量存储
    self.vector_store.add_documents(split_docs)

    # 重新创建检索器
    self.retriever = self.vector_store.as_retriever(
        search_kwargs={"k": settings.TOP_K}
    )

    # 重新构建链
    self._build_chain()

    # 持久化
    if self.persist:
        self.vector_store.save_local(self.vector_store_path)
```

**功能**：支持向已有向量存储添加新文档，实现知识库的增量更新。

## 2.7 主程序模块详解（main.py）

主程序提供了命令行接口，支持三种运行模式。

### 2.7.1 命令行参数解析

```python
parser = argparse.ArgumentParser(description="ChatPDF RAG 系统 - 专用于 PDF 文档的检索增强生成")
parser.add_argument(
    "--mode",
    type=str,
    choices=["build", "query", "interactive"],
    default="interactive",
    help="运行模式: build(构建向量存储), query(单次查询), interactive(交互模式)",
)
parser.add_argument(
    "--file",
    type=str,
    help="要加载的 PDF 文件路径（用于 build 模式）",
)
parser.add_argument(
    "--question",
    type=str,
    help="要查询的问题（用于 query 模式）",
)
parser.add_argument(
    "--vector-store",
    type=str,
    default="./vectorstore",
    help="向量存储路径",
)
parser.add_argument(
    "--append",
    action="store_true",
    help="增量添加模式：如果向量存储已存在，则追加文档而不是覆盖（仅用于 build 模式）",
)
```

**支持的参数**：
- `--mode`: 运行模式（build/query/interactive）
- `--file`: PDF 文件路径（build 模式必需，**仅支持 PDF 格式**）
- `--question`: 查询问题（query 模式必需）
- `--vector-store`: 向量存储路径（可选，默认 `./vectorstore`）
- `--append`: 增量添加模式（仅用于 build 模式）

### 2.7.2 构建模式（build）

```python
if args.mode == "build":
    # 构建模式：加载 PDF 文档并构建向量存储
    if not args.file:
        print("错误: build 模式需要指定 --file 参数（PDF 文件路径）")
        return
    
    file_path = Path(args.file)
    if not file_path.exists():
        print(f"错误: 文件不存在: {file_path}")
        return
    
    if file_path.suffix.lower() != ".pdf":
        print(f"错误: 仅支持 PDF 格式文件，当前文件: {file_path}")
        return
    
    print(f"正在加载 PDF 文档: {args.file}")
    documents = load_pdf(args.file)
    print(f"已加载 {len(documents)} 个文档页面")
    
    if args.append:
        print("使用增量添加模式...")
    else:
        print("正在构建向量存储...")
    rag.build_vector_store(documents, append=args.append)
    print(f"向量存储已构建并保存到: {args.vector_store}")
```

**功能**：
- 检查文件格式（仅支持 PDF）
- 加载指定 PDF 文档
- 构建向量存储
- 保存到指定路径

**使用示例**：
```bash
python main.py --mode build --file 2026年本科直博研究生招生专业目录.pdf
```

### 2.7.3 查询模式（query）

```python
elif args.mode == "query":
    # 查询模式：单次查询
    if not args.question:
        print("错误: query 模式需要指定 --question 参数")
        return

    print("正在加载向量存储...")
    try:
        rag.load_vector_store()
    except FileNotFoundError:
        print("错误: 向量存储不存在。请先使用 build 模式构建向量存储。")
        return

    print(f"问题: {args.question}")
    print("正在生成答案...")
    answer = rag.query(args.question)
    print(f"\n答案:\n{answer}")
```

**功能**：
- 加载已有向量存储
- 执行单次查询
- 输出答案

**使用示例**：
```bash
python main.py --mode query --question "2026江南大学本科直博研究生招生专业目录中，食品学院的招生专业有哪些？"
```

### 2.7.4 交互模式（interactive）

```python
elif args.mode == "interactive":
    # 交互模式：持续对话
    print("正在加载向量存储...")
    try:
        rag.load_vector_store()
    except FileNotFoundError:
        print("错误: 向量存储不存在。请先使用 build 模式构建向量存储。")
        print("示例命令: python main.py --mode build --file your_document.pdf")
        return

    print("ChatPDF RAG 系统已就绪！输入 'quit' 或 'exit' 退出。\n")

    while True:
        question = input("请输入您的问题: ").strip()

        if question.lower() in ["quit", "exit", "退出"]:
            print("再见！")
            break

        if not question:
            continue

        try:
            print("正在生成答案...")
            answer = rag.query(question)
            print(f"\n答案:\n{answer}\n")
        except Exception as e:
            print(f"错误: {e}\n")
```

**功能**：
- 启动交互式对话循环
- 持续接收用户问题
- 实时生成答案
- 支持退出命令（quit/exit/退出）

**使用示例**：
```bash
python main.py --mode interactive
```

## 2.8 Gradio Web 应用模块详解（gradio_app.py）

Gradio 是一个用于快速构建机器学习应用 Web 界面的 Python 库。本系统提供了基于 Gradio 的 Web 界面，让用户可以通过浏览器与 PDF 文档进行交互。

### 2.8.1 ChatPDFApp 类

```python
class ChatPDFApp:
    """ChatPDF Gradio 应用类"""
    
    def __init__(self):
        """初始化应用"""
        self.rag: Optional[RAGChain] = None
        self.vector_store_path = "./vectorstore"
        self.chat_history = []
```

**功能**：封装了 Web 应用的状态管理，包括 RAG 链实例、向量存储路径和对话历史。

### 2.8.2 PDF 上传功能：`upload_pdf()`

```python
def upload_pdf(self, file) -> str:
    """
    处理 PDF 文件上传
    
    Args:
        file: Gradio 文件对象（可能是文件路径字符串、文件对象或 None）
        
    Returns:
        状态消息
    """
    if file is None:
        return "请先上传 PDF 文件"
    
    try:
        # 处理文件路径（兼容不同版本的 Gradio）
        if isinstance(file, str):
            file_path = file
        elif isinstance(file, (list, tuple)) and len(file) > 0:
            file_path = file[0] if isinstance(file[0], str) else str(file[0])
        elif hasattr(file, 'name'):
            file_path = file.name
        else:
            file_path = str(file)
        
        # 检查文件扩展名
        if not file_path.lower().endswith('.pdf'):
            return "错误: 仅支持 PDF 格式文件"
        
        # 加载 PDF 文档
        documents = load_pdf(file_path)
        
        # 初始化 RAG 链
        self.rag = RAGChain(vector_store_path=self.vector_store_path)
        
        # 构建向量存储
        self.rag.build_vector_store(documents, append=False)
        
        # 清空对话历史
        self.chat_history = []
        
        return f"✅ PDF 上传成功！已加载 {len(documents)} 页，向量存储已构建完成。现在可以开始提问了！"
        
    except Exception as e:
        return f"❌ 错误: {str(e)}"
```

**功能**：
- 处理用户上传的 PDF 文件
- 兼容不同版本的 Gradio 文件对象格式
- 检查文件格式（仅支持 PDF）
- 加载 PDF 并构建向量存储
- 清空对话历史，准备新的对话

### 2.8.3 对话功能：`chat()`

```python
def chat(self, message: str, history: list) -> Tuple[list, str]:
    """
    处理用户消息并生成回复
    
    Args:
        message: 用户消息
        history: 对话历史
        
    Returns:
        (更新后的对话历史, 空字符串用于清空输入框)
    """
    if self.rag is None:
        return history + [[message, "❌ 请先上传 PDF 文件！"]], ""
    
    if not message.strip():
        return history, ""
    
    try:
        # 生成回答
        answer = self.rag.query(message)
        
        # 更新对话历史
        history.append([message, answer])
        
        return history, ""
        
    except Exception as e:
        error_msg = f"❌ 错误: {str(e)}"
        return history + [[message, error_msg]], ""
```

**功能**：
- 检查是否已上传 PDF 文件
- 调用 RAG 链生成答案
- 更新对话历史
- 处理错误情况

### 2.8.4 界面创建：`create_interface()`

```python
def create_interface():
    """创建 Gradio 界面"""
    app = ChatPDFApp()
    
    with gr.Blocks(css=css, title="ChatPDF - PDF 智能问答系统") as demo:
        gr.Markdown(
            """
            # 📚 ChatPDF - PDF 智能问答系统
            
            上传 PDF 文档，然后与文档进行对话。系统会基于文档内容为您提供准确的答案。
            """
        )
        
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("### 📄 上传 PDF 文档")
                file_upload = gr.File(
                    label="选择 PDF 文件",
                    file_types=[".pdf"]
                )
                upload_btn = gr.Button("上传并构建向量存储", variant="primary")
                status_text = gr.Textbox(
                    label="状态",
                    interactive=False,
                    lines=3
                )
            
            with gr.Column(scale=2):
                gr.Markdown("### 💬 对话区域")
                chatbot = gr.Chatbot(
                    label="对话历史",
                    height=500,
                    show_copy_button=True
                )
                msg_input = gr.Textbox(
                    label="输入问题",
                    placeholder="请输入您的问题...",
                    scale=4,
                    lines=2
                )
                submit_btn = gr.Button("发送", variant="primary", scale=1)
                clear_btn = gr.Button("清空对话", variant="secondary")
        
        # 绑定事件
        upload_btn.click(fn=app.upload_pdf, inputs=[file_upload], outputs=[status_text])
        submit_btn.click(fn=app.chat, inputs=[msg_input, chatbot], outputs=[chatbot, msg_input])
        msg_input.submit(fn=app.chat, inputs=[msg_input, chatbot], outputs=[chatbot, msg_input])
        clear_btn.click(fn=app.clear_chat, outputs=[chatbot])
    
    return demo
```

**界面布局**：
- **左侧列**：PDF 上传区域，包括文件选择、上传按钮和状态显示
- **右侧列**：对话区域，包括对话历史、输入框和操作按钮

**事件绑定**：
- 上传按钮：触发 PDF 上传和向量存储构建
- 发送按钮：触发对话功能
- 输入框回车：同样触发对话功能
- 清空按钮：清空对话历史

### 2.8.5 启动应用

```python
if __name__ == "__main__":
    demo = create_interface()
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False
    )
```

**启动参数**：
- `server_name="0.0.0.0"`: 允许从任何 IP 地址访问
- `server_port=7860`: 使用 7860 端口
- `share=False`: 不创建公共链接（设置为 True 可创建临时公共链接）

## 2.9 实验步骤1：安装依赖

首先，需要安装项目依赖。在项目根目录下运行：

```bash
pip install -r requirements.txt
```

**依赖说明**：

- `langchain`: LangChain 核心库
- `langchain-openai`: OpenAI 兼容接口
- `langchain-community`: 社区扩展（包含文档加载器等）
- `faiss-cpu`: FAISS 向量数据库（CPU 版本）
- `pydantic-settings`: 配置管理
- `pypdf`: PDF 文件处理
- `gradio==5.34.2`: Gradio Web 框架（注意版本号）

## 2.10 实验步骤2：构建向量存储

使用 PDF 文件构建向量存储：

```bash
python main.py --mode build --file 2026年本科直博研究生招生专业目录.pdf
```

**执行过程**：

1. 检查文件格式（必须是 PDF）
2. 加载 PDF 文件
3. 将文档分割成小块
4. 使用嵌入模型将每个块转换为向量
5. 使用 FAISS 创建向量索引
6. 保存到 `vectorstore/` 目录

**增量添加 PDF**：

如果已有向量存储，可以追加新的 PDF 文档：

```bash
python main.py --mode build --file new_document.pdf --append
```

## 2.11 实验步骤3：命令行交互式查询

构建向量存储后，启动交互式查询：

```bash
python main.py --mode interactive
```

在交互模式下，您可以持续提问，输入 `quit`、`exit` 或 `退出` 来结束对话。

## 2.12 实验步骤4：命令行单次查询

也可以使用单次查询模式：

```bash
python main.py --mode query --question "2026江南大学本科直博研究生招生专业目录中，食品学院的招生专业有哪些？"
```

## 2.13 实验步骤5：使用 Gradio Web 界面

### 2.13.1 启动 Web 应用

运行以下命令启动 Gradio Web 应用：

```bash
python gradio_app.py
```

### 2.13.2 使用 Web 界面

![image-20251113150808215](C:\Users\l1769\AppData\Roaming\Typora\typora-user-images\image-20251113150808215.png)

1. **打开浏览器**：访问 `http://localhost:7860`（如果在本机运行）或 `http://服务器IP:7860`（如果在远程服务器运行）

2. **上传 PDF 文件**：
   - 点击"选择 PDF 文件"按钮
   - 选择要处理的 PDF 文件
   - 点击"上传并构建向量存储"按钮
   - 等待上传和构建完成（状态栏会显示进度）

3. **开始对话**：
   - 在输入框中输入问题
   - 点击"发送"按钮或按回车键
   - 系统会基于 PDF 内容生成答案
   - 对话历史会显示在对话区域

4. **清空对话**：点击"清空对话"按钮可以清空对话历史

**Web 界面的优势**：
- 友好的图形界面，无需命令行操作
- 支持文件拖拽上传
- 实时显示对话历史
- 支持复制答案内容
- 适合演示和分享

# 三、实验任务

## 1. 基础任务

参考实验步骤，完成以下任务：

1. **环境搭建**：安装所有依赖，确保系统可以正常运行
2. **向量存储构建**：使用提供的 PDF 文件构建向量存储，观察构建过程和输出信息
3. **命令行交互式查询**：启动交互模式，尝试提出不同类型的问题，观察系统回答的质量
4. **命令行单次查询测试**：使用 query 模式测试不同的问题，记录答案质量
5. **Web 界面使用**：启动 Gradio Web 应用，通过 Web 界面上传 PDF 并进行对话，体验 Web 界面的便利性

## 2. 扩展任务

1. **多样化PDF解析**：
   - 尝试使用Qwen2.5-VL-7B多模态模型理解pdf内容，并提取内容进行Embedding
2. **多 PDF 文档知识库**：
   - 修改Gradio应用，使其支持rag对话和普通对话功能
   - 当存在向量数据库时，增量添加pdf文档内容
3. **Gradio 界面优化**：
   - 研究 Gradio 的更多功能（如主题定制、组件样式等）
   - 尝试添加新功能（如显示检索到的文档片段、支持多轮对话等）
   - 优化界面布局和用户体验

## 3. 实验报告要求

撰写实验报告，需要在实验报告中完成以下任务：

1. **实验过程记录**：
   - 记录完整的实验步骤，包括环境搭建、向量存储构建、命令行查询测试、Web 界面使用等
   - 提供关键步骤的截图或输出结果
   - 记录使用自定义 PDF 文档的实验过程和结果
   - 记录参数调优实验的过程和结果

2. **代码理解分析**：
   - 分析每个模块的功能和实现原理
   - 说明 RAG 系统的工作流程
   - 解释向量检索和答案生成的过程
   - 分析 Gradio Web 应用的实现原理

3. **思考题**：
   - **思考题1**：PDF 专用 RAG 系统相比通用 RAG 系统有什么优势和局限性？在什么场景下应该选择 PDF 专用系统？
   - **思考题2**：Web 界面相比命令行界面有什么优势？在什么场景下应该使用 Web 界面，什么场景下应该使用命令行界面？
   - **思考题3**：文档分割策略（chunk_size 和 chunk_overlap）对 PDF 文档的检索效果有什么影响？如何针对不同类型的 PDF 文档（如学术论文、技术手册、表格文档）选择合适的参数？
   - **思考题4**：RAG 技术在 PDF 文档处理领域有哪些潜在应用？请结合你的专业背景，谈谈 RAG 技术如何解决 PDF 文档相关的实际问题

4. **问题与改进**：
   - 记录实验过程中遇到的问题和解决方法
   - 提出对系统的改进建议
   - 思考如何优化检索效果和答案质量
   - 思考如何改进 Web 界面的用户体验

