"""
ChatPDF - 基于 LangChain 的 PDF RAG 系统
"""
__version__ = "1.0.0"

