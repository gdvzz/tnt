from langchain_openai import OpenAIEmbeddings

# 初始化 embeddings 模型
embeddings = OpenAIEmbeddings(
    model="qwen3-embedding-8b",
    openai_api_base="https://prodsvc.educg.net/serve-qwen3-embedding-8b/v1",
    openai_api_key="EMPTY",  # 如无需认证，填任意值
    check_embedding_ctx_length=False,     # 禁用上下文长度检查（部分自定义模型需要）
)

# 单文本 embedding
text = "这是一个测试文本"
vector = embeddings.embed_query(text)
print(f"向量维度: {len(vector)}")
print(f"前5个值: {vector[:5]}")

# 批量文本 embedding
texts = ["第一段文本", "第二段文本", "第三段文本"]
vectors = embeddings.embed_documents(texts)
print(f"批量生成 {len(vectors)} 个向量")
