"""
PDF 文档加载和分割工具 - 仅支持 PDF 格式
"""
from pathlib import Path
from typing import List, Union

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from config.settings import settings


def load_pdf(file_path: Union[str, Path]) -> List[Document]:
    """
    加载 PDF 文档
    
    Args:
        file_path: PDF 文件路径
    
    Returns:
        文档列表
    
    Raises:
        FileNotFoundError: 文件不存在
        ValueError: 文件不是 PDF 格式
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    suffix = file_path.suffix.lower()
    if suffix != ".pdf":
        raise ValueError(f"仅支持 PDF 格式文件，当前文件: {file_path}")
    
    # 使用 PyPDFLoader 加载 PDF
    loader = PyPDFLoader(str(file_path))
    documents = loader.load()
    
    return documents


def split_documents(documents: List[Document]) -> List[Document]:
    """
    将文档分割成小块
    
    Args:
        documents: 原始文档列表
    
    Returns:
        分割后的文档列表
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=settings.CHUNK_SIZE,
        chunk_overlap=settings.CHUNK_OVERLAP,
        length_function=len,
    )
    
    split_docs = text_splitter.split_documents(documents)
    return split_docs

