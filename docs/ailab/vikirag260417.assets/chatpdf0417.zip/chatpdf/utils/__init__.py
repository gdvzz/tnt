"""
工具模块 - 导出 PDF 文档加载器
"""
from .pdf_loader import load_pdf, split_documents

__all__ = ["load_pdf", "split_documents"]

