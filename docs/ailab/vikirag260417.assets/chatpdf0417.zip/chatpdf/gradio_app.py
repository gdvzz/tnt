"""
Gradio Web 应用 - 支持 PDF 上传和对话的 ChatPDF 系统
"""
import gradio as gr
import os
from typing import Tuple, Optional

from chains import RAGChain
from utils import load_pdf


class ChatPDFApp:
    """ChatPDF Gradio 应用类"""
    
    def __init__(self):
        """初始化应用"""
        self.rag: Optional[RAGChain] = None
        self.vector_store_path = "./vectorstore"
        self.chat_history = []
    
    def upload_pdf(self, file) -> str:
        """
        处理 PDF 文件上传
        
        Args:
            file: Gradio 文件对象（可能是文件路径字符串、文件对象或 None）
            
        Returns:
            状态消息
        """
        if file is None:
            return "请先上传 PDF 文件"
        
        try:
            # 处理文件路径（Gradio 5.34.2 的 File 组件通常返回文件路径字符串）
            # 但也可能返回文件对象，需要兼容处理
            if isinstance(file, str):
                file_path = file
            elif isinstance(file, (list, tuple)) and len(file) > 0:
                # 某些版本的 Gradio 可能返回列表
                file_path = file[0] if isinstance(file[0], str) else str(file[0])
            elif hasattr(file, 'name'):
                file_path = file.name
            else:
                file_path = str(file)
            
            # 检查文件扩展名
            if not file_path.lower().endswith('.pdf'):
                return "错误: 仅支持 PDF 格式文件"
            
            # 检查文件是否存在
            if not os.path.exists(file_path):
                return f"错误: 文件不存在: {file_path}"
            
            # 加载 PDF 文档
            print(f"正在加载 PDF 文档: {file_path}")
            documents = load_pdf(file_path)
            print(f"已加载 {len(documents)} 个文档页面")
            
            # 初始化 RAG 链
            self.rag = RAGChain(vector_store_path=self.vector_store_path)
            
            # 构建向量存储
            print("正在构建向量存储...")
            self.rag.build_vector_store(documents, append=False)
            
            # 清空对话历史
            self.chat_history = []
            
            return f"✅ PDF 上传成功！已加载 {len(documents)} 页，向量存储已构建完成。现在可以开始提问了！"
            
        except Exception as e:
            error_msg = f"❌ 错误: {str(e)}"
            print(error_msg)
            import traceback
            traceback.print_exc()
            return error_msg
    
    def chat(self, message: str, history: list) -> Tuple[list, str]:
        """
        处理用户消息并生成回复
        
        Args:
            message: 用户消息
            history: 对话历史
            
        Returns:
            (更新后的对话历史, 空字符串用于清空输入框)
        """
        if self.rag is None:
            return history + [[message, "❌ 请先上传 PDF 文件！"]], ""
        
        if not message.strip():
            return history, ""
        
        try:
            # 生成回答
            print(f"问题: {message}")
            answer = self.rag.query(message)
            print(f"答案: {answer}")
            
            # 更新对话历史
            history.append([message, answer])
            
            return history, ""
            
        except Exception as e:
            error_msg = f"❌ 错误: {str(e)}"
            print(error_msg)
            return history + [[message, error_msg]], ""
    
    def clear_chat(self) -> list:
        """清空对话历史"""
        self.chat_history = []
        return []


def create_interface():
    """创建 Gradio 界面"""
    app = ChatPDFApp()
    
    # 自定义 CSS
    css = """
    .gradio-container {
        font-family: 'Microsoft YaHei', Arial, sans-serif;
    }
    .chat-message {
        padding: 10px;
        margin: 5px 0;
    }
    """
    
    with gr.Blocks(css=css, title="ChatPDF - PDF 智能问答系统") as demo:
        gr.Markdown(
            """
            # 📚 ChatPDF - PDF 智能问答系统
            
            上传 PDF 文档，然后与文档进行对话。系统会基于文档内容为您提供准确的答案。
            """
        )
        
        with gr.Row():
            with gr.Column(scale=1):
                gr.Markdown("### 📄 上传 PDF 文档")
                file_upload = gr.File(
                    label="选择 PDF 文件",
                    file_types=[".pdf"]
                )
                upload_btn = gr.Button("上传并构建向量存储", variant="primary")
                status_text = gr.Textbox(
                    label="状态",
                    interactive=False,
                    lines=3
                )
            
            with gr.Column(scale=2):
                gr.Markdown("### 💬 对话区域")
                chatbot = gr.Chatbot(
                    label="对话历史",
                    height=500,
                    show_copy_button=True
                )
                with gr.Row():
                    msg_input = gr.Textbox(
                        label="输入问题",
                        placeholder="请输入您的问题...",
                        scale=4,
                        lines=2
                    )
                with gr.Row():
                    submit_btn = gr.Button("发送", variant="primary", scale=1)
                
                    clear_btn = gr.Button("清空对话", variant="secondary")
        
        # 绑定事件
        upload_btn.click(
            fn=app.upload_pdf,
            inputs=[file_upload],
            outputs=[status_text]
        )
        
        submit_btn.click(
            fn=app.chat,
            inputs=[msg_input, chatbot],
            outputs=[chatbot, msg_input]
        )
        
        msg_input.submit(
            fn=app.chat,
            inputs=[msg_input, chatbot],
            outputs=[chatbot, msg_input]
        )
        
        clear_btn.click(
            fn=app.clear_chat,
            outputs=[chatbot]
        )
    
    return demo


if __name__ == "__main__":
    demo = create_interface()
    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False
    )

