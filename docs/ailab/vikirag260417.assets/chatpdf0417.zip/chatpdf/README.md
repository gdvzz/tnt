# ChatPDF - PDF 专用 RAG 系统

基于 LangChain 构建的专门用于 PDF 文档的 RAG（Retrieval-Augmented Generation）系统，使用自定义的 Qwen 模型端点。

## 项目结构

```
chatpdf/
├── config/              # 配置模块
│   ├── __init__.py
│   └── settings.py      # 配置文件
├── models/              # 模型封装
│   ├── __init__.py
│   ├── llm.py          # LLM 模型封装
│   └── embedding.py     # 嵌入模型封装
├── chains/              # RAG 链
│   ├── __init__.py
│   └── rag_chain.py    # RAG 链实现
├── utils/               # 工具函数
│   ├── __init__.py
│   └── pdf_loader.py    # PDF 文档加载工具
├── vectorstore/         # 向量存储目录（自动创建）
├── main.py             # 主程序入口
├── requirements.txt    # 依赖文件
└── README.md           # 项目说明
```

## 功能特性

- ✅ 专门针对 PDF 文档优化
- ✅ 模块化设计，代码结构清晰
- ✅ 使用 FAISS 进行高效的向量检索
- ✅ 支持向量存储持久化
- ✅ 提供命令行接口和交互式对话模式
- ✅ 使用自定义 Qwen 模型端点

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 构建向量存储

首先，准备您的 PDF 文件，然后运行：

```bash
python main.py --mode build --file your_document.pdf
```

### 2. 交互式查询

构建向量存储后，可以启动交互式对话：

```bash
python main.py --mode interactive
```

### 3. 单次查询

也可以直接进行单次查询：

```bash
python main.py --mode query --question "您的问题"
```

### 4. 增量添加 PDF

如果已有向量存储，可以追加新的 PDF 文档：

```bash
python main.py --mode build --file new_document.pdf --append
```

## 配置说明

模型端点配置在 `config/settings.py` 中：

- **LLM 模型**: `https://prodsvc.educg.net/serve-qwen25-32b-instruct/v1`
- **嵌入模型**: `https://prodsvc.educg.net/serve-qwen3-embedding-8b/v1`

您可以通过修改 `config/settings.py` 或创建 `.env` 文件来自定义配置。

## 代码示例

### 在代码中使用

```python
from chains import RAGChain
from utils import load_pdf

# 初始化 RAG 链
rag = RAGChain()

# 加载 PDF 文档并构建向量存储
documents = load_pdf("your_document.pdf")
rag.build_vector_store(documents)

# 查询
answer = rag.query("您的问题是什么？")
print(answer)
```

### 加载已存在的向量存储

```python
from chains import RAGChain

rag = RAGChain()
rag.load_vector_store()
answer = rag.query("您的问题")
```

## 注意事项

1. 确保模型端点可访问
2. 首次运行需要构建向量存储
3. 向量存储会持久化到 `vectorstore/` 目录
4. 根据实际嵌入模型的维度调整 `EMBEDDING_DIMENSION` 配置
5. **仅支持 PDF 格式文件**，不支持 TXT、Markdown 等其他格式

## 许可证

MIT License

