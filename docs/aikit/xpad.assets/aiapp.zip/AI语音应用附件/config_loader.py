import json
import os
from typing import Dict, Any

class ConfigLoader:
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self._config: Dict[str, Any] = {}
        self.load_config()
    
    def load_config(self):
        """加载并验证配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                
            # 验证必要字段
            required_sections = ['models', 'timeouts']
            for section in required_sections:
                if section not in config:
                    raise ValueError(f"Missing required section: {section}")

            self._config = config

        except FileNotFoundError:
            raise RuntimeError(f"配置文件未找到: {os.path.abspath(self.config_path)}")
        except json.JSONDecodeError:
            raise RuntimeError("配置文件格式错误，必须是有效的JSON")
    
    @property
    def models(self) -> Dict[str, Dict[str, str]]:
        """获取所有模型的配置"""
        return self._config.get('models', {})
    
    def get_model_url(self, model_name: str) -> str:
        """获取指定模型的URL"""
        return self.models.get(model_name, {}).get('url', '')
    
    def get_model_id(self, model_name: str) -> str:
        """获取指定模型的model_id"""
        return self.models.get(model_name, {}).get('model_id', '')
    
    def get_api_key(self, model_name: str) -> str:
        """获取指定模型的api_key"""
        return self.models.get(model_name, {}).get('api_key', '')
    
    def get_tts_voice(self) -> str:
        """获取TTS语音配置（支持自定义参数）"""
        return self.models.get("tts", {}).get('voice', 'alloy')
    
    # 向后兼容：获取API端点（返回URL）
    @property
    def api_endpoints(self) -> Dict[str, str]:
        """获取API端点配置（向后兼容）"""
        return {
            name: config.get('url', '') 
            for name, config in self.models.items()
        }
    
    @property
    def timeouts(self) -> Dict[str, int]:
        """获取超时配置"""
        return self._config.get('timeouts', {})

# 单例配置对象
config = ConfigLoader()
